use master

go
Create Database Staff_Management
On Primary
(
	Name = 'Hotel_Perfect_Primary',
	FileName = 'D:\Belgium Campus\Second Year (2016)\PRG 221\Project 3\Sam_Mabaso_PRG221_Jansen_Neil_Project3\Staff_Management_Primary.mdf',
	Size = 10mb,
	MaxSize = 100mb,
	FileGrowth = 5%
)

LOG ON
(
	Name = 'Hotel_Perfect_Log',
	FileName = 'D:\Belgium Campus\Second Year (2016)\PRG 221\Project 3\Sam_Mabaso_PRG221_Jansen_Neil_Project3\Staff_Management_Log.ldf',
	Size = 5mb,
	MaxSize = 25mb,
	FileGrowth = 5%
)