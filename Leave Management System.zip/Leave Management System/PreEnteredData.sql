use Staff_Management

go
exec sp_InsertAdmin 'Neil', 'Jansen', 'Password1'
exec sp_InsertStaff 'Database Administrator', 'Armand', 'Swart', 'PukkieBoytjie'

exec sp_InsertCategories 'Family Responsibility', 10
exec sp_InsertCategories 'Maternity', 10
exec sp_InsertCategories 'Vacation', 10
exec sp_InsertCategories 'Annual Leave', 14
exec sp_InsertCategories 'Medical', 3