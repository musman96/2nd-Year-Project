use Staff_Management

go
Create Table tblStaff
(
	staffID int Primary Key identity(1,1),
	staffJobTitle varchar(100) not null,
	firstName varchar(30) not null,
	lastName varchar(30) not null,
	staffPassword varchar(30) not null
)

go
Create Table tblCategories
(
	categorieID int Primary Key identity(1,1),
	categoryName varchar(30) not null,
	lengthInDays int not null
)

go
Create Table tblLeave
(
	leaveID int Primary Key identity(1,1),
	staffIDFK int references tblStaff(staffID) not null,
	categorieIDFK int references tblCategories(categorieID) not null,
	leaveStatus varchar(10) not null,
	startDate date not null,
	endDate date not null
)

go
Create Table tblAdmin
(
	adminID int Primary Key identity(1,1),
	firstName varchar(30) not null,
	lastName varchar(30) not null,
	adminPassword varchar(30) not null
)

go
Create Table tblActiveRequests
(
	requestsID int Primary Key identity(1,1),
	staffIDFK int references tblStaff(staffID) not null,
	categorieIDFK int references tblCategories(categorieID) not null,
	leaveStatus varchar(10) not null,
	startDate date not null,
	endDate date not null
)