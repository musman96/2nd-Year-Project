use Staff_Management

go
Create Proc sp_UpdateStaff
(
	@title varchar(100),
	@name varchar(30),
	@surname varchar(30),
	@password varchar(30),
	@id int
)
AS
Begin
Update tblStaff
SET staffJobTitle = @title, firstName = @name, lastName = @surname, staffPassword = @password
WHERE staffID = @id
End

go
Create Proc sp_UpdateLeaveDays
(
	@newLength int,
	@id int
)
AS
Begin
Update tblCategories
SET lengthInDays = @newLength
WHERE categorieID = @id
End