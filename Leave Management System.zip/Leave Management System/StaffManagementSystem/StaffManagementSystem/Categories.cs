﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffManagementSystem
{
    class Categories
    {
        private int categorieID;
        private string categorieName;
        private int lengthInDays;

        public override string ToString()
        {
            return String.Format("{0}", this.CategorieName);
        }

        public Categories()
        {

        }

        public Categories(int categorieIDP, string categorieNameP, int lengthInDaysP)
        {
            this.categorieID = categorieIDP;
            this.categorieName = categorieNameP;
            this.lengthInDays = lengthInDaysP;
        }

        public Categories(string categorieNameP, int lengthInDaysP)
        {
            this.categorieName = categorieNameP;
            this.lengthInDays = lengthInDaysP;
        }

        public int LengthInDays
        {
            get { return lengthInDays; }
            set { lengthInDays = value; }
        }
        

        public string CategorieName
        {
            get { return categorieName; }
            set { categorieName = value; }
        }
        

        public int CategorieID
        {
            get { return categorieID; }
            set { categorieID = value; }
        }
        
    }
}
