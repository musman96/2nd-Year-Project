﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmStaffLogin : Form
    {
        public delegate void Restart();
        public int loginReturn = -1;
        public frmStaffLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputName, inputPassword;
            Restart r = ClearDetails;

            inputName = txtStaffLoginName.Text;
            inputPassword = txtStaffLoginPassword.Text;

            try
            {
                ValidateLoginData(inputName, inputPassword);
                loginReturn = ConnectToServer.SendLoopLogin("LoginStaff", inputName, inputPassword);

                if (loginReturn == 2)
                {                
                    DialogResult result;

                    result = MessageBox.Show("Welcome (Client): " + inputName, "Login Success", MessageBoxButtons.OK);

                    if (result == DialogResult.OK) // User input
                    {
                        List<string> readData = new List<string>();
                        Staff s = null;

                        readData = ConnectToServer.ReadStaffMembers("SelectStaff");

                        foreach (string item in readData)
                        {
                            string[] splitData;

                            int staffID;
                            string title, firstName, lastName, password;

                            splitData = item.Split(';');

                            staffID = int.Parse(splitData[0]);
                            title = splitData[1];
                            firstName = splitData[2];
                            lastName = splitData[3];
                            password = splitData[4];

                            if ((firstName.Equals(inputName) && (password.Equals(inputPassword))))
                            {
                                s = new Staff(staffID, title, firstName, lastName, password);
                            }
                        }
                        frmLeaveMenu lm = new frmLeaveMenu(s);
                        lm.Show();
                        this.Hide();
                    }   
                }
                else
                {
                    MessageBox.Show("Invalid Login Details", "Error");
                    r();
                }
            }
            catch (LoginError le)
            {
                MessageBox.Show(le.Message, "Error");
                r();
            }
        }

        public void ValidateLoginData(string inputName, string inputPassword)
        {
            if (((inputName.Contains(" ")) || (string.IsNullOrEmpty(inputName))))
            {
                throw new LoginError("Please Supply A Login Username");
            }
            else if (((inputPassword.Contains(" ")) || (string.IsNullOrEmpty(inputPassword))))
            {
                throw new LoginError("Please Supply A Login Password");
            }
        }

        public void ClearDetails()
        {
            txtStaffLoginName.Clear();
            txtStaffLoginPassword.Clear();

            txtStaffLoginName.Focus();
        }
    }
}
