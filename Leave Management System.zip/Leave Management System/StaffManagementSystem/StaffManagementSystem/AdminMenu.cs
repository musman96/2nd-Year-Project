﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmAdminMenu : Form
    {
        Admin adminMember;
        public frmAdminMenu(Admin a)
        {
            InitializeComponent();
            adminMember = a;
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to terminate this System?", "Terminate", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) // User input
            {
                Application.Exit();
            }
        }

        private void viewChatroomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChatroom chatroom = new frmChatroom("AdminMenu", adminMember);
            chatroom.Show();
            this.Hide();
        }

        private void addNewStaffMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddMember addStaff = new frmAddMember(adminMember);
            addStaff.Show();
            this.Hide();
        }

        private void manageStaffMembersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmManageStaff manageStaff = new frmManageStaff(adminMember);
            manageStaff.Show();
            this.Hide();
        }

        private void viewLeaveRequestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmViewRequests leaveRequests = new frmViewRequests(adminMember);
            leaveRequests.Show();
            this.Hide();
        }

        private void allocateLeaveDaysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAllocateDays allocateDays = new frmAllocateDays(adminMember);
            allocateDays.Show();
            this.Hide();
        }
    }
}
