﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{

    public partial class frmLeaveReports : Form
    {
        List<Leave> leave = new List<Leave>();
        List<Categories> categories = new List<Categories>();
        List<string> readData = new List<string>();
        List<string> bindList = new List<string>();

        Staff staffMember;
        public frmLeaveReports(Staff s)
        {
            InitializeComponent();
            staffMember = s;
        }

        private void btnBackFromReports_Click(object sender, EventArgs e)
        {
            frmLeaveMenu lm = new frmLeaveMenu(staffMember);
            lm.Show();
            this.Hide();
        }

        private void btnCloseByReports_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to terminate this System?", "Terminate", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) // User input
            {
                Application.Exit();
            }
        }

        private void frmLeaveReports_Load(object sender, EventArgs e)
        {
            readData = ConnectToServer.LoadLeaveTypes("SelectCategories");

            foreach (string item in readData)
            {
                string[] splitData;

                int categorieID, categorieLength;
                string categorieName;

                splitData = item.Split(';');

                categorieID = int.Parse(splitData[0]);
                categorieName = splitData[1];
                categorieLength = int.Parse(splitData[2]);

                categories.Add(new Categories(categorieID, categorieName, categorieLength));
            }

            readData = ConnectToServer.LoadLeave("SelectLeave", staffMember.StaffID);

            foreach (string reports in readData)
            {
                string[] splitData;
                int staffID, categorieID, leaveID;
                string status;
                DateTime startDate, endDate;

                splitData = reports.Split(';');

                leaveID = int.Parse(splitData[0]);
                staffID = int.Parse(splitData[1]);
                categorieID = int.Parse(splitData[2]);
                status = splitData[3];
                startDate = DateTime.Parse(splitData[4]);
                endDate = DateTime.Parse(splitData[5]);

                if (staffMember.StaffID.Equals(staffID))
                {
                    foreach (Categories catItem in categories)
                    {
                        if (catItem.CategorieID.Equals(categorieID))
                        {
                            leave.Add(new Leave(leaveID, staffMember, catItem, status, startDate, endDate));
                        }
                    }
                }
            }

            foreach (Leave item in leave)
            {
                bindList.Add(item.StaffClass.FirstName + " " + item.StaffClass.LastName + "\tLeave Type: " + item.CategoriesClass.CategorieName + "\tStatus: " + item.LeaveStatus + "\tStart Date: " + item.StartDate + "\tEnd Date: " + item.EndDate);
            }

            lstReports.DataSource = bindList;
        }
    }
}
