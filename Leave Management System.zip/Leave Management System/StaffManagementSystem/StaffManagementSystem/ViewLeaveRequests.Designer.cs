﻿namespace StaffManagementSystem
{
    partial class frmViewRequests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLeaveRequests = new System.Windows.Forms.Label();
            this.txtLeaveType = new System.Windows.Forms.TextBox();
            this.lblLeaveType = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblApprove = new System.Windows.Forms.Label();
            this.ckbYes = new System.Windows.Forms.CheckBox();
            this.ckbNo = new System.Windows.Forms.CheckBox();
            this.btnNotify = new System.Windows.Forms.Button();
            this.btnCloseByRequests = new System.Windows.Forms.Button();
            this.btnBackFromRequests = new System.Windows.Forms.Button();
            this.lstActiveRequests = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblLeaveRequests
            // 
            this.lblLeaveRequests.AutoSize = true;
            this.lblLeaveRequests.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLeaveRequests.Location = new System.Drawing.Point(12, 9);
            this.lblLeaveRequests.Name = "lblLeaveRequests";
            this.lblLeaveRequests.Size = new System.Drawing.Size(189, 27);
            this.lblLeaveRequests.TabIndex = 2;
            this.lblLeaveRequests.Text = "Leave Requests";
            // 
            // txtLeaveType
            // 
            this.txtLeaveType.Enabled = false;
            this.txtLeaveType.Location = new System.Drawing.Point(358, 70);
            this.txtLeaveType.Name = "txtLeaveType";
            this.txtLeaveType.Size = new System.Drawing.Size(201, 20);
            this.txtLeaveType.TabIndex = 3;
            // 
            // lblLeaveType
            // 
            this.lblLeaveType.AutoSize = true;
            this.lblLeaveType.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblLeaveType.Location = new System.Drawing.Point(355, 48);
            this.lblLeaveType.Name = "lblLeaveType";
            this.lblLeaveType.Size = new System.Drawing.Size(92, 17);
            this.lblLeaveType.TabIndex = 7;
            this.lblLeaveType.Text = "Leave Type";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblStartDate.Location = new System.Drawing.Point(355, 108);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(85, 17);
            this.lblStartDate.TabIndex = 8;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblEndDate.Location = new System.Drawing.Point(355, 163);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(77, 17);
            this.lblEndDate.TabIndex = 9;
            this.lblEndDate.Text = "End Date";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Enabled = false;
            this.dtpStartDate.Location = new System.Drawing.Point(358, 128);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(201, 20);
            this.dtpStartDate.TabIndex = 10;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Enabled = false;
            this.dtpEndDate.Location = new System.Drawing.Point(358, 183);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(201, 20);
            this.dtpEndDate.TabIndex = 11;
            // 
            // lblApprove
            // 
            this.lblApprove.AutoSize = true;
            this.lblApprove.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblApprove.Location = new System.Drawing.Point(355, 216);
            this.lblApprove.Name = "lblApprove";
            this.lblApprove.Size = new System.Drawing.Size(117, 17);
            this.lblApprove.TabIndex = 12;
            this.lblApprove.Text = "Approve Leave";
            // 
            // ckbYes
            // 
            this.ckbYes.AutoSize = true;
            this.ckbYes.Checked = true;
            this.ckbYes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbYes.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbYes.Location = new System.Drawing.Point(358, 247);
            this.ckbYes.Name = "ckbYes";
            this.ckbYes.Size = new System.Drawing.Size(53, 21);
            this.ckbYes.TabIndex = 13;
            this.ckbYes.Text = "Yes";
            this.ckbYes.UseVisualStyleBackColor = true;
            this.ckbYes.CheckedChanged += new System.EventHandler(this.ckbYes_CheckedChanged);
            // 
            // ckbNo
            // 
            this.ckbNo.AutoSize = true;
            this.ckbNo.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbNo.Location = new System.Drawing.Point(417, 247);
            this.ckbNo.Name = "ckbNo";
            this.ckbNo.Size = new System.Drawing.Size(48, 21);
            this.ckbNo.TabIndex = 14;
            this.ckbNo.Text = "No";
            this.ckbNo.UseVisualStyleBackColor = true;
            this.ckbNo.CheckedChanged += new System.EventHandler(this.ckbNo_CheckedChanged);
            // 
            // btnNotify
            // 
            this.btnNotify.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNotify.Location = new System.Drawing.Point(358, 315);
            this.btnNotify.Name = "btnNotify";
            this.btnNotify.Size = new System.Drawing.Size(201, 36);
            this.btnNotify.TabIndex = 15;
            this.btnNotify.Text = "Notify";
            this.btnNotify.UseVisualStyleBackColor = true;
            this.btnNotify.Click += new System.EventHandler(this.btnNotify_Click);
            // 
            // btnCloseByRequests
            // 
            this.btnCloseByRequests.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseByRequests.Location = new System.Drawing.Point(565, 315);
            this.btnCloseByRequests.Name = "btnCloseByRequests";
            this.btnCloseByRequests.Size = new System.Drawing.Size(107, 36);
            this.btnCloseByRequests.TabIndex = 17;
            this.btnCloseByRequests.Text = "Close";
            this.btnCloseByRequests.UseVisualStyleBackColor = true;
            this.btnCloseByRequests.Click += new System.EventHandler(this.btnCloseByRequests_Click);
            // 
            // btnBackFromRequests
            // 
            this.btnBackFromRequests.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackFromRequests.Location = new System.Drawing.Point(206, 315);
            this.btnBackFromRequests.Name = "btnBackFromRequests";
            this.btnBackFromRequests.Size = new System.Drawing.Size(107, 36);
            this.btnBackFromRequests.TabIndex = 16;
            this.btnBackFromRequests.Text = "Back";
            this.btnBackFromRequests.UseVisualStyleBackColor = true;
            this.btnBackFromRequests.Click += new System.EventHandler(this.btnBackFromRequests_Click);
            // 
            // lstActiveRequests
            // 
            this.lstActiveRequests.FormattingEnabled = true;
            this.lstActiveRequests.Location = new System.Drawing.Point(12, 48);
            this.lstActiveRequests.Name = "lstActiveRequests";
            this.lstActiveRequests.Size = new System.Drawing.Size(188, 303);
            this.lstActiveRequests.TabIndex = 18;
            this.lstActiveRequests.SelectedIndexChanged += new System.EventHandler(this.lstActiveRequests_SelectedIndexChanged);
            // 
            // frmViewRequests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(684, 361);
            this.Controls.Add(this.lstActiveRequests);
            this.Controls.Add(this.btnCloseByRequests);
            this.Controls.Add(this.btnBackFromRequests);
            this.Controls.Add(this.btnNotify);
            this.Controls.Add(this.ckbNo);
            this.Controls.Add(this.ckbYes);
            this.Controls.Add(this.lblApprove);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.lblLeaveType);
            this.Controls.Add(this.txtLeaveType);
            this.Controls.Add(this.lblLeaveRequests);
            this.MaximumSize = new System.Drawing.Size(700, 400);
            this.MinimumSize = new System.Drawing.Size(700, 400);
            this.Name = "frmViewRequests";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Leave Requests";
            this.Load += new System.EventHandler(this.frmViewRequests_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLeaveRequests;
        private System.Windows.Forms.TextBox txtLeaveType;
        private System.Windows.Forms.Label lblLeaveType;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Label lblApprove;
        private System.Windows.Forms.CheckBox ckbYes;
        private System.Windows.Forms.CheckBox ckbNo;
        private System.Windows.Forms.Button btnNotify;
        private System.Windows.Forms.Button btnCloseByRequests;
        private System.Windows.Forms.Button btnBackFromRequests;
        private System.Windows.Forms.ListBox lstActiveRequests;
    }
}