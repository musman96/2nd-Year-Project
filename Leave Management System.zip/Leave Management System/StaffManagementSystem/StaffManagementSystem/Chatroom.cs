﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using HelperLib;
using System.Threading;

namespace StaffManagementSystem
{
    public partial class frmChatroom : Form
    {
        public delegate void Restart();
        public string formName;
        public static List<string> listMessages = new List<string>();

        Staff staffMember;
        Admin adminMember;

        public static Socket clientSocket = ConnectToServer.clientSocket;
        public static byte[] receivedBuf = ConnectToServer.receivedBuf;

        public frmChatroom(string formNameP)
        {
            InitializeComponent();
            formName = formNameP;
        }
        public frmChatroom()
        {
            InitializeComponent();
        }

        public frmChatroom(string formNameP, Staff s)
        {
            InitializeComponent();
            formName = formNameP;
            staffMember = s;
        }

        public frmChatroom(string formNameP, Admin a)
        {
            InitializeComponent();
            formName = formNameP;
            adminMember = a;
        }

        private void btnBackFromChatroom_Click(object sender, EventArgs e)
        {
            if (formName == "LeaveForm")
            {
                frmLeaveMenu lm = new frmLeaveMenu(staffMember);
                lm.Show();
                this.Hide();
            }
            else if(formName == "AdminMenu")
            {
                frmAdminMenu am = new frmAdminMenu(adminMember);
                am.Show();
                this.Hide();
            }
        }

        private void btnCloseByChatroom_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to terminate this System?", "Terminate", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) // User input
            {
                Application.Exit();
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message;
            message = txtMessage.Text;
            Restart r = ClearDetails;

            try
            {
                ValidateData(message);

                if(adminMember != null)
                {
                    message = "(Admin) " + adminMember.FirstName + ">>\t" + message;
                }
                else if (staffMember != null)
                { 
                    message = "(Client) " + staffMember.FirstName + ">>\t" + message;
                }

                foreach (var item in lstChat.Items)
                {
                    listMessages.Add(item.ToString());
                }

                ConnectToServer.SendMessage("SendMessage" , message);

                lstChat.Items.Add(message);
            }
            catch (NullReferenceException nre)
            {
                MessageBox.Show(nre.Message, "THE FUCK");
            }
            catch (LoginError le)
            {
                MessageBox.Show(le.Message, "Error");             
            }
        }

        public void ClearDetails()
        {
            txtMessage.Clear();

            txtMessage.Focus();
        }

        public void ValidateData(string message)
        {
            if ((string.IsNullOrEmpty(message)))
            {
                throw new LoginError("Cannot Send Empty Message");
            }
        }

        public static void SetupMessenger()
        {
            
            clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(RecieveData), clientSocket);
        }

        public static void RecieveData(IAsyncResult ar)
        {
            Socket recieveSocket = (Socket)ar.AsyncState;

            int recieved = recieveSocket.EndReceive(ar);
            byte[] dataBuf = new byte[recieved];
            Array.Copy(receivedBuf, dataBuf, recieved);
            string test = (string)dataBuf.Deserialize();

            frmChatroom chat = new frmChatroom();
            chat.AddToList(test);

            Thread beginRecieve = new Thread(new ThreadStart(() =>
            {
                clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(RecieveData), clientSocket);
            }));

            beginRecieve.Start();
        }

        public void AddToList(string message)
        {
            lstChat.Items.Add(message);
        }

        private void frmChatroom_Load(object sender, EventArgs e)
        {
            SetupMessenger();
        }
    }
}
