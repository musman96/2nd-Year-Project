﻿namespace StaffManagementSystem
{
    partial class frmAllocateDays
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbTypes = new System.Windows.Forms.ComboBox();
            this.lblLeaveType = new System.Windows.Forms.Label();
            this.spnNoOfDays = new System.Windows.Forms.NumericUpDown();
            this.lblNoOfDays = new System.Windows.Forms.Label();
            this.btnCloseByAllocateDays = new System.Windows.Forms.Button();
            this.btnBackFromAllocateDays = new System.Windows.Forms.Button();
            this.btnAllocate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.spnNoOfDays)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbTypes
            // 
            this.cmbTypes.FormattingEnabled = true;
            this.cmbTypes.Location = new System.Drawing.Point(12, 39);
            this.cmbTypes.Name = "cmbTypes";
            this.cmbTypes.Size = new System.Drawing.Size(260, 21);
            this.cmbTypes.TabIndex = 0;
            this.cmbTypes.SelectedIndexChanged += new System.EventHandler(this.cmbTypes_SelectedIndexChanged);
            // 
            // lblLeaveType
            // 
            this.lblLeaveType.AutoSize = true;
            this.lblLeaveType.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLeaveType.Location = new System.Drawing.Point(12, 19);
            this.lblLeaveType.Name = "lblLeaveType";
            this.lblLeaveType.Size = new System.Drawing.Size(97, 17);
            this.lblLeaveType.TabIndex = 6;
            this.lblLeaveType.Text = "Leave Type:";
            // 
            // spnNoOfDays
            // 
            this.spnNoOfDays.Location = new System.Drawing.Point(15, 131);
            this.spnNoOfDays.Name = "spnNoOfDays";
            this.spnNoOfDays.Size = new System.Drawing.Size(128, 20);
            this.spnNoOfDays.TabIndex = 7;
            // 
            // lblNoOfDays
            // 
            this.lblNoOfDays.AutoSize = true;
            this.lblNoOfDays.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfDays.Location = new System.Drawing.Point(12, 92);
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.Size = new System.Drawing.Size(131, 17);
            this.lblNoOfDays.TabIndex = 8;
            this.lblNoOfDays.Text = "Number of Days:";
            // 
            // btnCloseByAllocateDays
            // 
            this.btnCloseByAllocateDays.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseByAllocateDays.Location = new System.Drawing.Point(165, 213);
            this.btnCloseByAllocateDays.Name = "btnCloseByAllocateDays";
            this.btnCloseByAllocateDays.Size = new System.Drawing.Size(107, 36);
            this.btnCloseByAllocateDays.TabIndex = 12;
            this.btnCloseByAllocateDays.Text = "Close";
            this.btnCloseByAllocateDays.UseVisualStyleBackColor = true;
            this.btnCloseByAllocateDays.Click += new System.EventHandler(this.btnCloseByAllocateDays_Click);
            // 
            // btnBackFromAllocateDays
            // 
            this.btnBackFromAllocateDays.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackFromAllocateDays.Location = new System.Drawing.Point(12, 213);
            this.btnBackFromAllocateDays.Name = "btnBackFromAllocateDays";
            this.btnBackFromAllocateDays.Size = new System.Drawing.Size(107, 36);
            this.btnBackFromAllocateDays.TabIndex = 11;
            this.btnBackFromAllocateDays.Text = "Back";
            this.btnBackFromAllocateDays.UseVisualStyleBackColor = true;
            this.btnBackFromAllocateDays.Click += new System.EventHandler(this.btnBackFromAllocateDays_Click);
            // 
            // btnAllocate
            // 
            this.btnAllocate.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllocate.Location = new System.Drawing.Point(165, 121);
            this.btnAllocate.Name = "btnAllocate";
            this.btnAllocate.Size = new System.Drawing.Size(107, 36);
            this.btnAllocate.TabIndex = 13;
            this.btnAllocate.Text = "Allocate";
            this.btnAllocate.UseVisualStyleBackColor = true;
            this.btnAllocate.Click += new System.EventHandler(this.btnAllocate_Click);
            // 
            // frmAllocateDays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnAllocate);
            this.Controls.Add(this.btnCloseByAllocateDays);
            this.Controls.Add(this.btnBackFromAllocateDays);
            this.Controls.Add(this.lblNoOfDays);
            this.Controls.Add(this.spnNoOfDays);
            this.Controls.Add(this.lblLeaveType);
            this.Controls.Add(this.cmbTypes);
            this.MaximumSize = new System.Drawing.Size(300, 300);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "frmAllocateDays";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Allocate Leave Days";
            this.Load += new System.EventHandler(this.frmAllocateDays_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spnNoOfDays)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbTypes;
        private System.Windows.Forms.Label lblLeaveType;
        private System.Windows.Forms.NumericUpDown spnNoOfDays;
        private System.Windows.Forms.Label lblNoOfDays;
        private System.Windows.Forms.Button btnCloseByAllocateDays;
        private System.Windows.Forms.Button btnBackFromAllocateDays;
        private System.Windows.Forms.Button btnAllocate;
    }
}