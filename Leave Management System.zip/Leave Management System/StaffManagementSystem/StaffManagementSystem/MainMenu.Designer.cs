﻿namespace StaffManagementSystem
{
    partial class frmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadStaffLogin = new System.Windows.Forms.Button();
            this.btnLoadAdminLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoadStaffLogin
            // 
            this.btnLoadStaffLogin.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnLoadStaffLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLoadStaffLogin.Font = new System.Drawing.Font("Elephant", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadStaffLogin.Location = new System.Drawing.Point(75, 70);
            this.btnLoadStaffLogin.Name = "btnLoadStaffLogin";
            this.btnLoadStaffLogin.Size = new System.Drawing.Size(131, 38);
            this.btnLoadStaffLogin.TabIndex = 0;
            this.btnLoadStaffLogin.Text = "Staff Login";
            this.btnLoadStaffLogin.UseVisualStyleBackColor = false;
            this.btnLoadStaffLogin.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLoadAdminLogin
            // 
            this.btnLoadAdminLogin.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnLoadAdminLogin.Font = new System.Drawing.Font("Elephant", 12F);
            this.btnLoadAdminLogin.Location = new System.Drawing.Point(75, 156);
            this.btnLoadAdminLogin.Name = "btnLoadAdminLogin";
            this.btnLoadAdminLogin.Size = new System.Drawing.Size(131, 38);
            this.btnLoadAdminLogin.TabIndex = 1;
            this.btnLoadAdminLogin.Text = "Admin Login";
            this.btnLoadAdminLogin.UseVisualStyleBackColor = false;
            this.btnLoadAdminLogin.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnLoadAdminLogin);
            this.Controls.Add(this.btnLoadStaffLogin);
            this.MaximumSize = new System.Drawing.Size(300, 300);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "frmMainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.frmMainMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadStaffLogin;
        private System.Windows.Forms.Button btnLoadAdminLogin;
    }
}