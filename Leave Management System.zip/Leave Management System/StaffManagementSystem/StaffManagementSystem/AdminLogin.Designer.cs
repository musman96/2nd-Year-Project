﻿namespace StaffManagementSystem
{
    partial class frmAdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdminLogin = new System.Windows.Forms.Button();
            this.txtAdminLoginPassword = new System.Windows.Forms.TextBox();
            this.txtAdminLoginName = new System.Windows.Forms.TextBox();
            this.lblAdminPassword = new System.Windows.Forms.Label();
            this.lblAdminNameLogin = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdminLogin
            // 
            this.btnAdminLogin.BackColor = System.Drawing.Color.SeaShell;
            this.btnAdminLogin.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnAdminLogin.Location = new System.Drawing.Point(71, 199);
            this.btnAdminLogin.Name = "btnAdminLogin";
            this.btnAdminLogin.Size = new System.Drawing.Size(145, 35);
            this.btnAdminLogin.TabIndex = 9;
            this.btnAdminLogin.Text = "Login";
            this.btnAdminLogin.UseVisualStyleBackColor = false;
            this.btnAdminLogin.Click += new System.EventHandler(this.btnAdminLogin_Click);
            // 
            // txtAdminLoginPassword
            // 
            this.txtAdminLoginPassword.Location = new System.Drawing.Point(71, 115);
            this.txtAdminLoginPassword.Name = "txtAdminLoginPassword";
            this.txtAdminLoginPassword.PasswordChar = '*';
            this.txtAdminLoginPassword.Size = new System.Drawing.Size(145, 20);
            this.txtAdminLoginPassword.TabIndex = 8;
            // 
            // txtAdminLoginName
            // 
            this.txtAdminLoginName.Location = new System.Drawing.Point(71, 46);
            this.txtAdminLoginName.Name = "txtAdminLoginName";
            this.txtAdminLoginName.Size = new System.Drawing.Size(145, 20);
            this.txtAdminLoginName.TabIndex = 7;
            // 
            // lblAdminPassword
            // 
            this.lblAdminPassword.AutoSize = true;
            this.lblAdminPassword.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblAdminPassword.Location = new System.Drawing.Point(68, 95);
            this.lblAdminPassword.Name = "lblAdminPassword";
            this.lblAdminPassword.Size = new System.Drawing.Size(84, 17);
            this.lblAdminPassword.TabIndex = 6;
            this.lblAdminPassword.Text = "Password:";
            // 
            // lblAdminNameLogin
            // 
            this.lblAdminNameLogin.AutoSize = true;
            this.lblAdminNameLogin.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminNameLogin.Location = new System.Drawing.Point(68, 26);
            this.lblAdminNameLogin.Name = "lblAdminNameLogin";
            this.lblAdminNameLogin.Size = new System.Drawing.Size(55, 17);
            this.lblAdminNameLogin.TabIndex = 5;
            this.lblAdminNameLogin.Text = "Name:";
            // 
            // frmAdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnAdminLogin);
            this.Controls.Add(this.txtAdminLoginPassword);
            this.Controls.Add(this.txtAdminLoginName);
            this.Controls.Add(this.lblAdminPassword);
            this.Controls.Add(this.lblAdminNameLogin);
            this.MaximumSize = new System.Drawing.Size(300, 300);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "frmAdminLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Login Module";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdminLogin;
        private System.Windows.Forms.TextBox txtAdminLoginPassword;
        private System.Windows.Forms.TextBox txtAdminLoginName;
        private System.Windows.Forms.Label lblAdminPassword;
        private System.Windows.Forms.Label lblAdminNameLogin;
    }
}