﻿namespace StaffManagementSystem
{
    partial class frmLeaveReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPreviousReports = new System.Windows.Forms.Label();
            this.lstReports = new System.Windows.Forms.ListBox();
            this.btnBackFromReports = new System.Windows.Forms.Button();
            this.btnCloseByReports = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPreviousReports
            // 
            this.lblPreviousReports.AutoSize = true;
            this.lblPreviousReports.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreviousReports.Location = new System.Drawing.Point(134, 57);
            this.lblPreviousReports.Name = "lblPreviousReports";
            this.lblPreviousReports.Size = new System.Drawing.Size(210, 27);
            this.lblPreviousReports.TabIndex = 0;
            this.lblPreviousReports.Text = "Previous Reports";
            // 
            // lstReports
            // 
            this.lstReports.FormattingEnabled = true;
            this.lstReports.Location = new System.Drawing.Point(12, 87);
            this.lstReports.Name = "lstReports";
            this.lstReports.Size = new System.Drawing.Size(660, 316);
            this.lstReports.TabIndex = 1;
            // 
            // btnBackFromReports
            // 
            this.btnBackFromReports.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackFromReports.Location = new System.Drawing.Point(12, 413);
            this.btnBackFromReports.Name = "btnBackFromReports";
            this.btnBackFromReports.Size = new System.Drawing.Size(107, 36);
            this.btnBackFromReports.TabIndex = 7;
            this.btnBackFromReports.Text = "Back";
            this.btnBackFromReports.UseVisualStyleBackColor = true;
            this.btnBackFromReports.Click += new System.EventHandler(this.btnBackFromReports_Click);
            // 
            // btnCloseByReports
            // 
            this.btnCloseByReports.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseByReports.Location = new System.Drawing.Point(565, 409);
            this.btnCloseByReports.Name = "btnCloseByReports";
            this.btnCloseByReports.Size = new System.Drawing.Size(107, 36);
            this.btnCloseByReports.TabIndex = 8;
            this.btnCloseByReports.Text = "Close";
            this.btnCloseByReports.UseVisualStyleBackColor = true;
            this.btnCloseByReports.Click += new System.EventHandler(this.btnCloseByReports_Click);
            // 
            // frmLeaveReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(684, 461);
            this.Controls.Add(this.btnCloseByReports);
            this.Controls.Add(this.btnBackFromReports);
            this.Controls.Add(this.lstReports);
            this.Controls.Add(this.lblPreviousReports);
            this.MaximumSize = new System.Drawing.Size(700, 500);
            this.MinimumSize = new System.Drawing.Size(700, 500);
            this.Name = "frmLeaveReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Recent Leave Reports";
            this.Load += new System.EventHandler(this.frmLeaveReports_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPreviousReports;
        private System.Windows.Forms.ListBox lstReports;
        private System.Windows.Forms.Button btnBackFromReports;
        private System.Windows.Forms.Button btnCloseByReports;
    }
}