﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using HelperLib;


namespace StaffManagementSystem
{
    public class ConnectToServer
    {
        public static Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        public static byte[] receivedBuf = new byte[1024];
        public static int validLogin = 0;
        public static  string recievedMessage;

        public ConnectToServer()
        {
            LoopConnect();     
        }

        public static void SetupMessenger()
        {
            //clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(RecieveData), clientSocket);
        }

        public static void RecieveData(IAsyncResult ar)
        {
            Socket recieveSocket = (Socket)ar.AsyncState;

            int recieved = recieveSocket.EndReceive(ar);
            byte[] dataBuf = new byte[recieved];
            Array.Copy(receivedBuf, dataBuf, recieved);
            string test = (string)dataBuf.Deserialize();

            Thread beginRecieve = new Thread(new ThreadStart(() =>
            {
                clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(RecieveData), clientSocket);
            }));

            beginRecieve.Start();

        }

        public static void RecieveCallback(IAsyncResult ar)
        {
            Socket socket = (Socket)ar.AsyncState;

            if(socket.Connected)
            {
                int recieved;

                try
                {
                    recieved = socket.EndReceive(ar);
                }
                catch (Exception e)
                {
                    return;
                }

                if(recieved != 0)
                {
                    byte[] dataBuf = new byte[recieved];
                    Array.Copy(receivedBuf, dataBuf, recieved);
                    string reply = (string)dataBuf.Deserialize();
                    validLogin = int.Parse(reply);
                    MessageBox.Show(validLogin.ToString());
                }
            }
        }

        public static void AcceptCallBack(IAsyncResult ar)
        {
            Socket socket = clientSocket.EndAccept(ar);

            Thread beginRecieve = new Thread(new ThreadStart(() =>
            {
                socket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(RecieveCallback), socket);
            }));

            beginRecieve.Start();

            Thread beginAccept = new Thread(new ThreadStart(() =>
            {
                clientSocket.BeginAccept(new AsyncCallback(AcceptCallBack), null);
            }));

            beginAccept.Start();
        }

        public static List<string> LoadLeaveTypes(string request)
        {
            List<string> leaveData = new List<string>();
            while (true)
            {
                string req = request;
                clientSocket.Send(req.Serialize());

                if (req.Contains("Select"))
                {
                    byte[] receivedBuf = new byte[1024];
                    int rev = clientSocket.Receive(receivedBuf);

                    if (rev != 0)
                    {
                        byte[] data = new byte[rev];
                        Array.Copy(receivedBuf, data, rev);
                        leaveData = (List<string>)receivedBuf.Deserialize();
                        return leaveData;
                    }
                }
            }
        }

        public static int SendLoopLogin(string request, string name, string password)
        {
            while(true)
            {
                string req = request + ";" + name + ";" + password;
                clientSocket.Send(req.Serialize());
                
                if(req.Contains("Login"))
                {
                    byte[] receivedBuf = new byte[1024];
                    int rev = clientSocket.Receive(receivedBuf);
                    
                    if(rev != 0)
                    {
                        byte[] data = new byte[rev];
                        Array.Copy(receivedBuf, data, rev);
                        validLogin = int.Parse((string)receivedBuf.Deserialize());
                        return validLogin;
                    }
                }
            }
        }

        public static void InsertStaffMember(string request, string title, string name, string surname, string password)
        {
            string req = request + ";" + title + ";" + name + ";" + surname + ";" + password;
            clientSocket.Send(req.Serialize());
        }

        public static void DeleteStaff(string request, int id)
        {
            string req = request + ";" + id;
            clientSocket.Send(req.Serialize());
        }

        public static List<string> LoadLeave(string request, int id)
        {
            List<string> leaveData = new List<string>();
            while (true)
            {
                string req = request + ";" + id;
                clientSocket.Send(req.Serialize());

                if (req.Contains("Select"))
                {
                    byte[] receivedBuf = new byte[1024];
                    int rev = clientSocket.Receive(receivedBuf);

                    if (rev != 0)
                    {
                        byte[] data = new byte[rev];
                        Array.Copy(receivedBuf, data, rev);
                        leaveData = (List<string>)receivedBuf.Deserialize();
                        return leaveData;
                    }
                }
            }
        }

        public static void DeleteActiveRequest(string request, int id)
        {
            string req = request + ";" + id;
            clientSocket.Send(req.Serialize());
        }

        public static void SaveLeaveData(string request, int staffID, int categorieID, string leaveStatus, DateTime startDate, DateTime endDate)
        {
            string req = request + ";" + staffID.ToString() + ";" + categorieID.ToString() + ";" + leaveStatus + ";" + startDate.ToString() + ";" + endDate.ToString();
            clientSocket.Send(req.Serialize());
        }

        public static List<string> LoadActiveReports(string request)
        {
            List<string> leaveData = new List<string>();
            while (true)
            {
                string req = request;
                clientSocket.Send(req.Serialize());

                if (req.Contains("Select"))
                {
                    byte[] receivedBuf = new byte[1024];
                    int rev = clientSocket.Receive(receivedBuf);

                    if (rev != 0)
                    {
                        byte[] data = new byte[rev];
                        Array.Copy(receivedBuf, data, rev);
                        leaveData = (List<string>)receivedBuf.Deserialize();
                        return leaveData;
                    }
                }
            }
        }

        public static void SaveActiveRequest(string request, int staffID, int categorieID, string leaveStatus, DateTime startDate, DateTime endDate)
        {
            string req = request + ";" + staffID.ToString() + ";" + categorieID.ToString() + ";" + leaveStatus + ";" + startDate.ToString() + ";" + endDate.ToString();
            clientSocket.Send(req.Serialize());
        }

        public static List<string> LoadActiveReportsForStaffMember(string request, int id)
        {
            List<string> leaveData = new List<string>();
            while (true)
            {
                string req = request + ";" + id;
                clientSocket.Send(req.Serialize());

                if (req.Contains("Select"))
                {
                    byte[] receivedBuf = new byte[1024];
                    int rev = clientSocket.Receive(receivedBuf);

                    if (rev != 0)
                    {
                        byte[] data = new byte[rev];
                        Array.Copy(receivedBuf, data, rev);
                        leaveData = (List<string>)receivedBuf.Deserialize();
                        return leaveData;
                    }
                }
            }
        }       

        public static void UpdateCategories(string request, decimal length , int id)
        {
            string req = request + ";" + length.ToString() + ";" + id.ToString();
            clientSocket.Send(req.Serialize());
        }

        public static void UpdateStaff(string request, string title, string name, string surname, string password, int id)
        {
            string req = request + ";" + title + ";" + name + ";" + surname + ";" + password + ";" + id.ToString();
            clientSocket.Send(req.Serialize());
        }

        public static void SendMessage(string request, string message)
        {
            string req = request + ";" + message;
            clientSocket.Send(req.Serialize());
        }

        public static List<string> ReadAdmin(string request)
        {
            List<string> staffData = new List<string>();
            while (true)
            {
                string req = request;
                clientSocket.Send(req.Serialize());

                if (req.Contains("Select"))
                {
                    byte[] receivedBuf = new byte[1024];
                    int rev = clientSocket.Receive(receivedBuf);

                    if (rev != 0)
                    {
                        byte[] data = new byte[rev];
                        Array.Copy(receivedBuf, data, rev);
                        staffData = (List<string>)receivedBuf.Deserialize();
                        return staffData;
                    }
                }
            }
        }

        public static List<string> ReadStaffMembers(string request)
        {
            List<string> staffData = new List<string>();
            while (true)
            {
                string req = request;
                clientSocket.Send(req.Serialize());

                if (req.Contains("Select"))
                {
                    byte[] receivedBuf = new byte[1024];
                    int rev = clientSocket.Receive(receivedBuf);

                    if (rev != 0)
                    {
                        byte[] data = new byte[rev];
                        Array.Copy(receivedBuf, data, rev);
                        staffData = (List<string>)receivedBuf.Deserialize();
                        return staffData;
                    }
                }
            }
        }

        public static void LoopConnect()
        {
            int attempts = 0;
            while (!clientSocket.Connected)
            {
                try
                {
                    attempts++;
                    clientSocket.Connect(IPAddress.Loopback, 3128);
                }
                catch (SocketException)
                {
                    MessageBox.Show("Number of Connection Attempts : " + attempts, "Connection Attempts");
                }
            }

            MessageBox.Show("Server connection has been established!", "Server Connection Success", MessageBoxButtons.OK);
        }
    }
}
