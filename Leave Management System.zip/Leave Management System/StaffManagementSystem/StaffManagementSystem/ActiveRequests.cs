﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffManagementSystem
{
    class ActiveRequests
    {
        private int leaveID;
        private Staff staffClass;
        private Categories categoriesClass;
        private string leaveStatus;
        private DateTime startDate;
        private DateTime endDate;

        public ActiveRequests()
        {

        }

        public ActiveRequests(int leaveIDP, Staff staffClassP, Categories categoriesClassP, string leaveStatusP, DateTime startDateP, DateTime endDateP)
        {
            this.leaveID = leaveIDP;
            this.staffClass = staffClassP;
            this.categoriesClass = categoriesClassP;
            this.leaveStatus = leaveStatusP;
            this.startDate = startDateP;
            this.endDate = endDateP;
        }

        public ActiveRequests(Staff staffClassP, Categories categoriesClassP, string leaveStatusP, DateTime startDateP, DateTime endDateP)
        {
            this.staffClass = staffClassP;
            this.categoriesClass = categoriesClassP;
            this.leaveStatus = leaveStatusP;
            this.startDate = startDateP;
            this.endDate = endDateP;
        }

        public DateTime EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }
        

        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }
        

        public string LeaveStatus
        {
            get { return leaveStatus; }
            set { leaveStatus = value; }
        }
        

        public Categories CategoriesClass
        {
            get { return categoriesClass; }
            set { categoriesClass = value; }
        }
        

        public Staff StaffClass
        {
            get { return staffClass; }
            set { staffClass = value; }
        }
        

        public int LeaveID
        {
            get { return leaveID; }
            set { leaveID = value; }
        }
    }
}
