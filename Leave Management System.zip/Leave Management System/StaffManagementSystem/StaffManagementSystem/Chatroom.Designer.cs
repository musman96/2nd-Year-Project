﻿namespace StaffManagementSystem
{
    partial class frmChatroom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstChat = new System.Windows.Forms.ListBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnCloseByChatroom = new System.Windows.Forms.Button();
            this.btnBackFromChatroom = new System.Windows.Forms.Button();
            this.lblChatroom = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstChat
            // 
            this.lstChat.FormattingEnabled = true;
            this.lstChat.Location = new System.Drawing.Point(12, 42);
            this.lstChat.Name = "lstChat";
            this.lstChat.Size = new System.Drawing.Size(658, 290);
            this.lstChat.TabIndex = 0;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(14, 352);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(545, 20);
            this.txtMessage.TabIndex = 1;
            // 
            // btnSend
            // 
            this.btnSend.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSend.Location = new System.Drawing.Point(565, 352);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(107, 36);
            this.btnSend.TabIndex = 11;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnCloseByChatroom
            // 
            this.btnCloseByChatroom.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseByChatroom.Location = new System.Drawing.Point(563, 413);
            this.btnCloseByChatroom.Name = "btnCloseByChatroom";
            this.btnCloseByChatroom.Size = new System.Drawing.Size(107, 36);
            this.btnCloseByChatroom.TabIndex = 13;
            this.btnCloseByChatroom.Text = "Close";
            this.btnCloseByChatroom.UseVisualStyleBackColor = true;
            this.btnCloseByChatroom.Click += new System.EventHandler(this.btnCloseByChatroom_Click);
            // 
            // btnBackFromChatroom
            // 
            this.btnBackFromChatroom.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackFromChatroom.Location = new System.Drawing.Point(12, 413);
            this.btnBackFromChatroom.Name = "btnBackFromChatroom";
            this.btnBackFromChatroom.Size = new System.Drawing.Size(107, 36);
            this.btnBackFromChatroom.TabIndex = 12;
            this.btnBackFromChatroom.Text = "Back";
            this.btnBackFromChatroom.UseVisualStyleBackColor = true;
            this.btnBackFromChatroom.Click += new System.EventHandler(this.btnBackFromChatroom_Click);
            // 
            // lblChatroom
            // 
            this.lblChatroom.AutoSize = true;
            this.lblChatroom.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChatroom.Location = new System.Drawing.Point(274, 12);
            this.lblChatroom.Name = "lblChatroom";
            this.lblChatroom.Size = new System.Drawing.Size(126, 27);
            this.lblChatroom.TabIndex = 14;
            this.lblChatroom.Text = "Chatroom";
            // 
            // frmChatroom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(684, 461);
            this.Controls.Add(this.lblChatroom);
            this.Controls.Add(this.btnCloseByChatroom);
            this.Controls.Add(this.btnBackFromChatroom);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.lstChat);
            this.MaximumSize = new System.Drawing.Size(700, 500);
            this.MinimumSize = new System.Drawing.Size(700, 500);
            this.Name = "frmChatroom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chatroom";
            this.Load += new System.EventHandler(this.frmChatroom_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstChat;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnCloseByChatroom;
        private System.Windows.Forms.Button btnBackFromChatroom;
        private System.Windows.Forms.Label lblChatroom;
    }
}