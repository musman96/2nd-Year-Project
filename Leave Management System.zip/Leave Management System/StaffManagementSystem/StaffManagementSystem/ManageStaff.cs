﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmManageStaff : Form
    {
        public List<Staff> staff = new List<Staff>();
        public List<string> readStaff = new List<string>();
        public delegate void Restart();
        public int selectedID;
        Admin adminMember;
        public frmManageStaff(Admin a)
        {
            InitializeComponent();
            adminMember = a;
        }

        private void btnCloseByManage_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to terminate this System?", "Terminate", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) // User input
            {
                Application.Exit();
            }
        }

        private void btnBackFromManage_Click(object sender, EventArgs e)
        {
            frmAdminMenu am = new frmAdminMenu(adminMember);
            am.Show();
            this.Hide();
        }

        private void frmManageStaff_Load(object sender, EventArgs e)
        {
            readStaff = ConnectToServer.ReadStaffMembers("SelectStaff");

            foreach (string item in readStaff)
            {
                string[] splitData;

                int staffID;
                string title, firstName, lastName, password;

                splitData = item.Split(';');

                staffID = int.Parse(splitData[0]);
                title = splitData[1];
                firstName = splitData[2];
                lastName = splitData[3];
                password = splitData[4];

                staff.Add(new Staff(staffID, title, firstName, lastName, password));
            }

            lstStaffMembers.DataSource = staff;
        }

        private void lstStaffMembers_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = lstStaffMembers.SelectedItem.ToString();

            foreach (Staff item in staff)
            {
               if(selectedItem.Equals(item.FirstName + " " + item.LastName))
               {
                   txtFirstName.Text = item.FirstName;
                   txtLastName.Text = item.LastName;
                   txtJobTitle.Text = item.JobTitle;
                   txtPassword.Text = item.Password;
                   selectedID = item.StaffID;
               }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string firstName, lastName, title, password;
            Restart r = ClearDetails;

            firstName = txtFirstName.Text;
            lastName = txtLastName.Text;
            title = txtJobTitle.Text;
            password = txtPassword.Text;

            try
            {
                ValidateData(firstName, lastName, title, password);
                ConnectToServer.UpdateStaff("UpdateStaff", title, firstName, lastName, password, selectedID);

                DialogResult result;

                result = MessageBox.Show("Staff Member Updated Successfully", "Save Successfull", MessageBoxButtons.OK);

                if (result == DialogResult.OK) // User input
                {
                    frmAdminMenu am = new frmAdminMenu(adminMember);
                    am.Show();
                    this.Hide();
                }

            }
            catch (LoginError le)
            {
                MessageBox.Show(le.Message, "Error");
                r();
            }
        }

        public void ValidateData(string firstName, string lastName, string title, string password)
        {
            if (((firstName.Contains(" ")) || (string.IsNullOrEmpty(firstName))))
            {
                throw new LoginError("Please Supply A First Name");
            }
            else if (((lastName.Contains(" ")) || (string.IsNullOrEmpty(lastName))))
            {
                throw new LoginError("Please Supply A Last Name");
            }
            else if (string.IsNullOrEmpty(title))
            {
                throw new LoginError("Please Supply A Job Title");
            }
            else if (((password.Contains(" ")) || (string.IsNullOrEmpty(password))))
            {
                throw new LoginError("Please Supply A Password");
            }
        }

        public void ClearDetails()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtJobTitle.Clear();
            txtPassword.Clear();

            txtFirstName.Focus();
        }

        private void btnDeleteStaff_Click(object sender, EventArgs e)
        {
            ConnectToServer.DeleteStaff("DeleteStaff", selectedID);

            DialogResult result;

            result = MessageBox.Show("Staff Member Deleted Successfully", "Save Successfull", MessageBoxButtons.OK);

            if (result == DialogResult.OK) // User input
            {
                frmAdminMenu am = new frmAdminMenu(adminMember);
                am.Show();
                this.Hide();
            }
        }
    }
}
