﻿namespace StaffManagementSystem
{
    partial class frmApplyLeave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReason = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.cmbReasons = new System.Windows.Forms.ComboBox();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.btnBackFromApplyLeave = new System.Windows.Forms.Button();
            this.btnApplyLeave = new System.Windows.Forms.Button();
            this.lblApplyForLeave = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblReason
            // 
            this.lblReason.AutoSize = true;
            this.lblReason.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReason.Location = new System.Drawing.Point(37, 61);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(114, 17);
            this.lblReason.TabIndex = 0;
            this.lblReason.Text = "Leave Reason:";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndDate.Location = new System.Drawing.Point(37, 166);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(130, 17);
            this.lblEndDate.TabIndex = 1;
            this.lblEndDate.Text = "Leave End Date:";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartDate.Location = new System.Drawing.Point(37, 111);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(138, 17);
            this.lblStartDate.TabIndex = 2;
            this.lblStartDate.Text = "Leave Start Date:";
            // 
            // cmbReasons
            // 
            this.cmbReasons.FormattingEnabled = true;
            this.cmbReasons.Location = new System.Drawing.Point(217, 57);
            this.cmbReasons.Name = "cmbReasons";
            this.cmbReasons.Size = new System.Drawing.Size(200, 21);
            this.cmbReasons.TabIndex = 3;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(217, 107);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpStartDate.TabIndex = 4;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Location = new System.Drawing.Point(217, 162);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(200, 20);
            this.dtpEndDate.TabIndex = 5;
            // 
            // btnBackFromApplyLeave
            // 
            this.btnBackFromApplyLeave.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackFromApplyLeave.Location = new System.Drawing.Point(12, 213);
            this.btnBackFromApplyLeave.Name = "btnBackFromApplyLeave";
            this.btnBackFromApplyLeave.Size = new System.Drawing.Size(107, 36);
            this.btnBackFromApplyLeave.TabIndex = 6;
            this.btnBackFromApplyLeave.Text = "Back";
            this.btnBackFromApplyLeave.UseVisualStyleBackColor = true;
            this.btnBackFromApplyLeave.Click += new System.EventHandler(this.btnBackFromApplyLeave_Click);
            // 
            // btnApplyLeave
            // 
            this.btnApplyLeave.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApplyLeave.Location = new System.Drawing.Point(365, 213);
            this.btnApplyLeave.Name = "btnApplyLeave";
            this.btnApplyLeave.Size = new System.Drawing.Size(107, 36);
            this.btnApplyLeave.TabIndex = 7;
            this.btnApplyLeave.Text = "Apply";
            this.btnApplyLeave.UseVisualStyleBackColor = true;
            this.btnApplyLeave.Click += new System.EventHandler(this.btnApplyLeave_Click);
            // 
            // lblApplyForLeave
            // 
            this.lblApplyForLeave.AutoSize = true;
            this.lblApplyForLeave.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApplyForLeave.Location = new System.Drawing.Point(129, 9);
            this.lblApplyForLeave.Name = "lblApplyForLeave";
            this.lblApplyForLeave.Size = new System.Drawing.Size(211, 31);
            this.lblApplyForLeave.TabIndex = 8;
            this.lblApplyForLeave.Text = "Apply For Leave";
            // 
            // frmApplyLeave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(484, 261);
            this.Controls.Add(this.lblApplyForLeave);
            this.Controls.Add(this.btnApplyLeave);
            this.Controls.Add(this.btnBackFromApplyLeave);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.cmbReasons);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblReason);
            this.MaximumSize = new System.Drawing.Size(500, 300);
            this.MinimumSize = new System.Drawing.Size(500, 300);
            this.Name = "frmApplyLeave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leave Apply Form";
            this.Load += new System.EventHandler(this.frmApplyLeave_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblReason;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.ComboBox cmbReasons;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Button btnBackFromApplyLeave;
        private System.Windows.Forms.Button btnApplyLeave;
        private System.Windows.Forms.Label lblApplyForLeave;
    }
}