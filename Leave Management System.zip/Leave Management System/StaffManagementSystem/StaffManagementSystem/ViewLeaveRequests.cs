﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmViewRequests : Form
    {
        List<Leave> leave = new List<Leave>();
        List<Categories> categories = new List<Categories>();
        List<string> readData = new List<string>();
        List<Staff> staff = new List<Staff>();
        Admin adminMember;
        public frmViewRequests(Admin a)
        {
            InitializeComponent();
            adminMember = a;
        }

        private void btnCloseByRequests_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to terminate this System?", "Terminate", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) // User input
            {
                Application.Exit();
            }
        }

        private void btnBackFromRequests_Click(object sender, EventArgs e)
        {
            frmAdminMenu am = new frmAdminMenu(adminMember);
            am.Show();
            this.Hide();
        }

        private void frmViewRequests_Load(object sender, EventArgs e)
        {
            loadForm();
        }

        private void loadForm()
        {
            readData = ConnectToServer.LoadLeaveTypes("SelectCategories");

            foreach (string item in readData)
            {
                string[] splitData;

                int categorieID, categorieLength;
                string categorieName;

                splitData = item.Split(';');

                categorieID = int.Parse(splitData[0]);
                categorieName = splitData[1];
                categorieLength = int.Parse(splitData[2]);

                categories.Add(new Categories(categorieID, categorieName, categorieLength));
            }

            readData = ConnectToServer.ReadStaffMembers("SelectStaff");

            foreach (string item in readData)
            {
                string[] splitData;

                int staffID;
                string title, firstName, lastName, password;

                splitData = item.Split(';');

                staffID = int.Parse(splitData[0]);
                title = splitData[1];
                firstName = splitData[2];
                lastName = splitData[3];
                password = splitData[4];

                staff.Add(new Staff(staffID, title, firstName, lastName, password));
            }

            readData = ConnectToServer.LoadActiveReports("SelectActiveReports");

            foreach (string reports in readData)
            {
                string[] splitData;
                int staffID, categorieID, requestID;
                string status;
                DateTime startDate, endDate;

                splitData = reports.Split(';');

                requestID = int.Parse(splitData[0]);
                staffID = int.Parse(splitData[1]);
                categorieID = int.Parse(splitData[2]);
                status = splitData[3];
                startDate = DateTime.Parse(splitData[4]);
                endDate = DateTime.Parse(splitData[5]);

                foreach (Staff staffItem in staff)
                {
                    if (staffItem.StaffID.Equals(staffID))
                    {
                        foreach (Categories catItem in categories)
                        {
                            if (catItem.CategorieID.Equals(categorieID))
                            {
                                leave.Add(new Leave(requestID, staffItem, catItem, status, startDate, endDate));
                            }
                        }
                    }
                }
            }



            lstActiveRequests.DataSource = leave;
        }

        private void lstActiveRequests_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = lstActiveRequests.SelectedItem.ToString();

            foreach (Leave item in leave)
            {
                if ((item.LeaveID + ". " + item.StaffClass.FirstName + " " + item.StaffClass.LastName) == selectedItem)
                {
                    dtpStartDate.Value = item.StartDate;
                    dtpEndDate.Value = item.EndDate;
                    txtLeaveType.Text = item.CategoriesClass.CategorieName;
                }
            }
        }

        private void ckbYes_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbYes.Checked)
            {
                ckbNo.Checked = false;
            }
        }

        private void ckbNo_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbNo.Checked)
            {
                ckbYes.Checked = false;
            }
        }

        private void btnNotify_Click(object sender, EventArgs e)
        {
            DialogResult result;

            if(ckbYes.Checked)
            {
                result = MessageBox.Show("Are you sure you want allow leave status?", "Confirm", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes) // User input
                {
                    foreach (Leave item in leave)
                    {
                        if ((item.LeaveID + ". " + item.StaffClass.FirstName + " " + item.StaffClass.LastName) == lstActiveRequests.SelectedItem.ToString())
                        {
                            ConnectToServer.SaveLeaveData("InsertLeaveData", item.StaffClass.StaffID, item.CategoriesClass.CategorieID, "Granted", item.StartDate, item.EndDate);
                            ConnectToServer.DeleteActiveRequest("DeleteActiveRequest", item.LeaveID);

                            frmAdminMenu am = new frmAdminMenu(adminMember);
                            am.Show();
                            this.Hide();
                        }
                    }
                }
            }
            else if(ckbNo.Checked)
            {
                result = MessageBox.Show("Are you sure you want allow leave status?", "Confirm", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes) // User input
                {
                    foreach (Leave item in leave)
                    {
                        if ((item.LeaveID + ". " + item.StaffClass.FirstName + " " + item.StaffClass.LastName) == lstActiveRequests.SelectedItem.ToString())
                        {
                            ConnectToServer.SaveLeaveData("InsertLeaveData", item.StaffClass.StaffID, item.CategoriesClass.CategorieID, "Denied", item.StartDate, item.EndDate);
                            ConnectToServer.DeleteActiveRequest("DeleteActiveRequest", item.LeaveID);

                            frmAdminMenu am = new frmAdminMenu(adminMember);
                            am.Show();
                            this.Hide();
                        }
                    }
                }
            }
        }
    }
}
