﻿namespace StaffManagementSystem
{
    partial class frmStaffLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStaffNameLogin = new System.Windows.Forms.Label();
            this.lblStaffPassword = new System.Windows.Forms.Label();
            this.txtStaffLoginName = new System.Windows.Forms.TextBox();
            this.txtStaffLoginPassword = new System.Windows.Forms.TextBox();
            this.btnStaffLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblStaffNameLogin
            // 
            this.lblStaffNameLogin.AutoSize = true;
            this.lblStaffNameLogin.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStaffNameLogin.Location = new System.Drawing.Point(61, 41);
            this.lblStaffNameLogin.Name = "lblStaffNameLogin";
            this.lblStaffNameLogin.Size = new System.Drawing.Size(55, 17);
            this.lblStaffNameLogin.TabIndex = 0;
            this.lblStaffNameLogin.Text = "Name:";
            // 
            // lblStaffPassword
            // 
            this.lblStaffPassword.AutoSize = true;
            this.lblStaffPassword.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblStaffPassword.Location = new System.Drawing.Point(61, 110);
            this.lblStaffPassword.Name = "lblStaffPassword";
            this.lblStaffPassword.Size = new System.Drawing.Size(84, 17);
            this.lblStaffPassword.TabIndex = 1;
            this.lblStaffPassword.Text = "Password:";
            // 
            // txtStaffLoginName
            // 
            this.txtStaffLoginName.Location = new System.Drawing.Point(64, 61);
            this.txtStaffLoginName.Name = "txtStaffLoginName";
            this.txtStaffLoginName.Size = new System.Drawing.Size(145, 20);
            this.txtStaffLoginName.TabIndex = 2;
            // 
            // txtStaffLoginPassword
            // 
            this.txtStaffLoginPassword.Location = new System.Drawing.Point(64, 130);
            this.txtStaffLoginPassword.Name = "txtStaffLoginPassword";
            this.txtStaffLoginPassword.PasswordChar = '*';
            this.txtStaffLoginPassword.Size = new System.Drawing.Size(145, 20);
            this.txtStaffLoginPassword.TabIndex = 3;
            // 
            // btnStaffLogin
            // 
            this.btnStaffLogin.BackColor = System.Drawing.Color.SeaShell;
            this.btnStaffLogin.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnStaffLogin.Location = new System.Drawing.Point(64, 214);
            this.btnStaffLogin.Name = "btnStaffLogin";
            this.btnStaffLogin.Size = new System.Drawing.Size(145, 35);
            this.btnStaffLogin.TabIndex = 4;
            this.btnStaffLogin.Text = "Login";
            this.btnStaffLogin.UseVisualStyleBackColor = false;
            this.btnStaffLogin.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmStaffLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnStaffLogin);
            this.Controls.Add(this.txtStaffLoginPassword);
            this.Controls.Add(this.txtStaffLoginName);
            this.Controls.Add(this.lblStaffPassword);
            this.Controls.Add(this.lblStaffNameLogin);
            this.MaximumSize = new System.Drawing.Size(300, 300);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "frmStaffLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Staff Login Module";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStaffNameLogin;
        private System.Windows.Forms.Label lblStaffPassword;
        private System.Windows.Forms.TextBox txtStaffLoginName;
        private System.Windows.Forms.TextBox txtStaffLoginPassword;
        private System.Windows.Forms.Button btnStaffLogin;
    }
}