﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmAllocateDays : Form
    {
        List<Categories> categories = new List<Categories>();
        List<string> readCategories = new List<string>();
        public int selectedID;
        Admin adminMember;
        public frmAllocateDays(Admin a)
        {
            InitializeComponent();
            adminMember = a;
        }

        private void btnCloseByAllocateDays_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to terminate this System?", "Terminate", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) // User input
            {
                Application.Exit();
            }
        }

        private void btnBackFromAllocateDays_Click(object sender, EventArgs e)
        {
            frmAdminMenu am = new frmAdminMenu(adminMember);
            am.Show();
            this.Hide();
        }

        private void btnAllocate_Click(object sender, EventArgs e)
        {
            decimal days = spnNoOfDays.Value;

            DialogResult resultOption;

            resultOption = MessageBox.Show("Are you sure you wish to allocate " + days.ToString() + " towards " + cmbTypes.Text + "?", "Validate", MessageBoxButtons.YesNo);
            if (resultOption == DialogResult.Yes) // User input
            {
                ConnectToServer.UpdateCategories("UpdateCategories", days , selectedID);

                DialogResult result;

                result = MessageBox.Show("Succesfully allocated Leave Days", "Save Successfull", MessageBoxButtons.OK);

                if (result == DialogResult.OK) // User input
                {
                    frmAdminMenu am = new frmAdminMenu(adminMember);
                    am.Show();
                    this.Hide();
                }
            }
        }

        private void frmAllocateDays_Load(object sender, EventArgs e)
        {
            readCategories = ConnectToServer.LoadLeaveTypes("SelectCategories");

            foreach (string item in readCategories)
            {
                string[] splitData;

                int categorieID, categorieLength;
                string categorieName;

                splitData = item.Split(';');

                categorieID = int.Parse(splitData[0]);
                categorieName = splitData[1];
                categorieLength = int.Parse(splitData[2]);

                categories.Add(new Categories(categorieID, categorieName, categorieLength));
            }

            cmbTypes.DataSource = categories;
        }

        private void cmbTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategorie = cmbTypes.Text;

            foreach (Categories item in categories)
            {
                if(item.CategorieName.Equals(selectedCategorie))
                {
                    selectedID = item.CategorieID;
                    spnNoOfDays.Value = item.LengthInDays;
                }
            }
        }
    }
}
