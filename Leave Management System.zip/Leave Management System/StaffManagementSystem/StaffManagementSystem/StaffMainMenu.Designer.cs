﻿namespace StaffManagementSystem
{
    partial class frmLeaveMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applyForLeaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previousLeaveReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outstandingLeaveRequestsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewChatroomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(684, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "msOptions";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applyForLeaveToolStripMenuItem,
            this.previousLeaveReportsToolStripMenuItem,
            this.outstandingLeaveRequestsToolStripMenuItem,
            this.viewChatroomToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.menuToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // applyForLeaveToolStripMenuItem
            // 
            this.applyForLeaveToolStripMenuItem.Name = "applyForLeaveToolStripMenuItem";
            this.applyForLeaveToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.applyForLeaveToolStripMenuItem.Text = "Apply for Leave";
            this.applyForLeaveToolStripMenuItem.Click += new System.EventHandler(this.applyForLeaveToolStripMenuItem_Click);
            // 
            // previousLeaveReportsToolStripMenuItem
            // 
            this.previousLeaveReportsToolStripMenuItem.Name = "previousLeaveReportsToolStripMenuItem";
            this.previousLeaveReportsToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.previousLeaveReportsToolStripMenuItem.Text = "Previous Leave Reports";
            this.previousLeaveReportsToolStripMenuItem.Click += new System.EventHandler(this.previousLeaveReportsToolStripMenuItem_Click);
            // 
            // outstandingLeaveRequestsToolStripMenuItem
            // 
            this.outstandingLeaveRequestsToolStripMenuItem.Name = "outstandingLeaveRequestsToolStripMenuItem";
            this.outstandingLeaveRequestsToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.outstandingLeaveRequestsToolStripMenuItem.Text = "Outstanding Leave Requests";
            this.outstandingLeaveRequestsToolStripMenuItem.Click += new System.EventHandler(this.outstandingLeaveRequestsToolStripMenuItem_Click);
            // 
            // viewChatroomToolStripMenuItem
            // 
            this.viewChatroomToolStripMenuItem.Name = "viewChatroomToolStripMenuItem";
            this.viewChatroomToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.viewChatroomToolStripMenuItem.Text = "View Chatroom";
            this.viewChatroomToolStripMenuItem.Click += new System.EventHandler(this.viewChatroomToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // frmLeaveMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::StaffManagementSystem.Properties.Resources._50_year_Promise_by_elsevilla;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(684, 461);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(700, 500);
            this.MinimumSize = new System.Drawing.Size(700, 500);
            this.Name = "frmLeaveMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leave Menu";
            this.Load += new System.EventHandler(this.frmLeaveMenu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applyForLeaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previousLeaveReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outstandingLeaveRequestsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewChatroomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
    }
}