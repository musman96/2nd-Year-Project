﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmSplashScreen : Form
    {
        Timer tmr;

        public frmSplashScreen()
        {
            InitializeComponent();
        }

        private void frmSplashScreen_Shown(object sender, EventArgs e)
        {
            tmr = new Timer();
            tmr.Interval = 3000;
            tmr.Start();
            tmr.Tick += tmr_Tick;
        }

        void tmr_Tick(object sender, EventArgs e)
        {
            tmr.Stop();
            frmMainMenu mm = new frmMainMenu();
            mm.Show();
            this.Hide();
        }
    }
}
