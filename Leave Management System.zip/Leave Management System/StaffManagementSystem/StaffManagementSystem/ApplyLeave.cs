﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmApplyLeave : Form
    {
        List<Categories> categories = new List<Categories>();
        List<string> readCategories = new List<string>();
        Staff staffMember;
        public frmApplyLeave(Staff s)
        {
            InitializeComponent();
            staffMember = s;
        }

        private void btnBackFromApplyLeave_Click(object sender, EventArgs e)
        {
            frmLeaveMenu lm = new frmLeaveMenu(staffMember);
            lm.Show();
            this.Hide();
        }

        private void btnApplyLeave_Click(object sender, EventArgs e)
        {
            DateTime startDate = dtpStartDate.Value;
            DateTime endDate = dtpEndDate.Value;
            int days;
            string selectedReason = cmbReasons.Text;

            if(startDate < DateTime.Today)
            {
                MessageBox.Show("Invalid Start Date Selected", "Error in Selection", MessageBoxButtons.OK);
            }
            else if (endDate < startDate)
            {
                MessageBox.Show("Invalid End Date Selected", "Error in Selection", MessageBoxButtons.OK);
            }
            else
            {
                days = (endDate - startDate).Days;

                foreach (Categories item in categories)
                {
                    if (item.CategorieName.Equals(selectedReason))
                    {
                        if (days > item.LengthInDays)
                        {
                            MessageBox.Show("Max amount of days allocated towards " + item.CategorieName + " is " + item.LengthInDays, "Error in Selection", MessageBoxButtons.OK);
                        }
                        else
                        {
                            DialogResult resultOption;

                            resultOption = MessageBox.Show("Are you sure you wish to apply for " + selectedReason + " leave from " + startDate.Date.ToLongDateString() + " to " + endDate.Date.ToLongDateString() + "?", "Validate", MessageBoxButtons.YesNo);
                            if (resultOption == DialogResult.Yes) // User input
                            {
                                Leave l = new Leave(staffMember, item, "Pending", startDate, endDate);

                                ConnectToServer.SaveActiveRequest("InsertActiveRequest", l.StaffClass.StaffID, l.CategoriesClass.CategorieID, l.LeaveStatus, l.StartDate, l.EndDate);

                                DialogResult result;

                                result = MessageBox.Show("Succesfully allocated Leave Days", "Save Successfull", MessageBoxButtons.OK);

                                if (result == DialogResult.OK) // User input
                                {
                                    frmLeaveMenu lm = new frmLeaveMenu(staffMember);
                                    lm.Show();
                                    this.Hide();
                                }
                            }
                        }

                    }
                }
            }
        }

        private void frmApplyLeave_Load(object sender, EventArgs e)
        {
            readCategories = ConnectToServer.LoadLeaveTypes("SelectCategories");

            foreach (string item in readCategories)
            {
                string[] splitData;

                int categorieID, categorieLength;
                string categorieName;

                splitData = item.Split(';');

                categorieID = int.Parse(splitData[0]);
                categorieName = splitData[1];
                categorieLength = int.Parse(splitData[2]);

                categories.Add(new Categories(categorieID, categorieName, categorieLength));
            }

            cmbReasons.DataSource = categories;
        }
    }
}
