﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmAdminLogin : Form
    {
        public delegate void Restart();
        private int loginReturn = -1;

        public frmAdminLogin()
        {
            InitializeComponent();
           
        }

        private void btnAdminLogin_Click(object sender, EventArgs e)
        {
            string inputName, inputPassword;
            Restart r = ClearDetails;

            inputName = txtAdminLoginName.Text;
            inputPassword = txtAdminLoginPassword.Text;

            try
            {
                ValidateLoginData(inputName, inputPassword);
                loginReturn = ConnectToServer.SendLoopLogin("LoginAdmin", inputName, inputPassword);

                if (loginReturn == 2)
                {
                    DialogResult result;

                    result = MessageBox.Show("Welcome (Admin): " + inputName, "Login Success", MessageBoxButtons.OK);

                    if (result == DialogResult.OK) // User input
                    {
                        List<string> readData = new List<string>();
                        Admin a = null;

                        readData = ConnectToServer.ReadAdmin("SelectAdmin");

                        foreach (string item in readData)
                        {
                            string[] splitData;

                            int adminID;
                            string firstName, lastName, password;

                            splitData = item.Split(';');

                            adminID = int.Parse(splitData[0]);
                            firstName = splitData[1];
                            lastName = splitData[2];
                            password = splitData[3];

                            if ((firstName.Equals(inputName) && (password.Equals(inputPassword))))
                            {
                                a = new Admin(adminID, firstName, lastName, password);
                            }
                        }
                        frmAdminMenu am = new frmAdminMenu(a);
                        am.Show();
                        this.Hide();
                    }                  
                }
                else
                {
                    MessageBox.Show("Invalid Login Details", "Error");
                    r();
                }
            }
            catch (LoginError le)
            {
                MessageBox.Show(le.Message, "Error");
                r();
            }
        }

        public void ValidateLoginData(string inputName, string inputPassword)
        {
            if (((inputName.Contains(" ")) || (string.IsNullOrEmpty(inputName))))
            {
                throw new LoginError("Please Supply A Login Username");
            }
            else if (((inputPassword.Contains(" ")) || (string.IsNullOrEmpty(inputPassword))))
            {
                throw new LoginError("Please Supply A Login Password");
            }
        }

        public void ClearDetails()
        {
            txtAdminLoginName.Clear();
            txtAdminLoginPassword.Clear();

            txtAdminLoginName.Focus();
        }
    }
}
