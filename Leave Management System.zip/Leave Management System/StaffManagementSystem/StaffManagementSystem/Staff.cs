﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffManagementSystem
{
    public class Staff
    {
        private int staffID;
        private string jobTitle;
        private string firstName;
        private string lastname;
        private string password;

        public override string ToString()
        {
            return String.Format("{0} {1}", this.FirstName, this.LastName);
        }

        public Staff()
        {

        }

        public Staff(int staffIDP, string jobTitleP, string firstNameP, string lastnameP, string passwordP)
        {
            this.staffID = staffIDP;
            this.jobTitle = jobTitleP;
            this.firstName = firstNameP;
            this.lastname = lastnameP;
            this.password = passwordP;
        }

        public Staff(string jobTitleP, string firstNameP, string lastnameP, string passwordP)
        {
            this.jobTitle = jobTitleP;
            this.firstName = firstNameP;
            this.lastname = lastnameP;
            this.password = passwordP;
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        

        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }
        

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        

        public string JobTitle
        {
            get { return jobTitle; }
            set { jobTitle = value; }
        }
        

        public int StaffID
        {
            get { return staffID; }
            set { staffID = value; }
        }
        
    }
}
