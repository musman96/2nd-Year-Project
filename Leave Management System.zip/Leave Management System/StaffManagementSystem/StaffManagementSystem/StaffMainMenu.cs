﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaffManagementSystem
{
    public partial class frmLeaveMenu : Form
    {
        Staff staffMember;
        public frmLeaveMenu(Staff staffP)
        {
            InitializeComponent();
            staffMember = staffP;
        }

        private void applyForLeaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmApplyLeave applyLeave = new frmApplyLeave(staffMember);
            applyLeave.Show();
            this.Hide();
        }

        private void previousLeaveReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLeaveReports leaveReports = new frmLeaveReports(staffMember);
            leaveReports.Show();
            this.Hide();
        }

        private void outstandingLeaveRequestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmOutstandingRequests outstandingRequests = new frmOutstandingRequests(staffMember);
            outstandingRequests.Show();
            this.Hide();
        }

        private void viewChatroomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChatroom chatroom = new frmChatroom("LeaveForm", staffMember);
            chatroom.Show();
            this.Hide();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to terminate this System?", "Terminate", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) // User input
            {
                Application.Exit();
            }
        }

        private void frmLeaveMenu_Load(object sender, EventArgs e)
        {
            
        }
    }
}
