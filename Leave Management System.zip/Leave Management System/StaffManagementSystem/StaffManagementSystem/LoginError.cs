﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaffManagementSystem
{
    class LoginError : Exception
    {
        public LoginError(string message) : base(message) { }
    }
}
