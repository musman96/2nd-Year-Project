﻿namespace StaffManagementSystem
{
    partial class frmAdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allocateLeaveDaysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewLeaveRequestsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageStaffMembersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewStaffMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewChatroomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(684, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "msAdminMenu";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allocateLeaveDaysToolStripMenuItem,
            this.viewLeaveRequestsToolStripMenuItem,
            this.manageStaffMembersToolStripMenuItem,
            this.addNewStaffMemberToolStripMenuItem,
            this.viewChatroomToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.menuToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // allocateLeaveDaysToolStripMenuItem
            // 
            this.allocateLeaveDaysToolStripMenuItem.Name = "allocateLeaveDaysToolStripMenuItem";
            this.allocateLeaveDaysToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.allocateLeaveDaysToolStripMenuItem.Text = "Allocate Leave Days";
            this.allocateLeaveDaysToolStripMenuItem.Click += new System.EventHandler(this.allocateLeaveDaysToolStripMenuItem_Click);
            // 
            // viewLeaveRequestsToolStripMenuItem
            // 
            this.viewLeaveRequestsToolStripMenuItem.Name = "viewLeaveRequestsToolStripMenuItem";
            this.viewLeaveRequestsToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.viewLeaveRequestsToolStripMenuItem.Text = "View Leave Requests";
            this.viewLeaveRequestsToolStripMenuItem.Click += new System.EventHandler(this.viewLeaveRequestsToolStripMenuItem_Click);
            // 
            // manageStaffMembersToolStripMenuItem
            // 
            this.manageStaffMembersToolStripMenuItem.Name = "manageStaffMembersToolStripMenuItem";
            this.manageStaffMembersToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.manageStaffMembersToolStripMenuItem.Text = "Manage Staff Members";
            this.manageStaffMembersToolStripMenuItem.Click += new System.EventHandler(this.manageStaffMembersToolStripMenuItem_Click);
            // 
            // addNewStaffMemberToolStripMenuItem
            // 
            this.addNewStaffMemberToolStripMenuItem.Name = "addNewStaffMemberToolStripMenuItem";
            this.addNewStaffMemberToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.addNewStaffMemberToolStripMenuItem.Text = "Add New Staff Member";
            this.addNewStaffMemberToolStripMenuItem.Click += new System.EventHandler(this.addNewStaffMemberToolStripMenuItem_Click);
            // 
            // viewChatroomToolStripMenuItem
            // 
            this.viewChatroomToolStripMenuItem.Name = "viewChatroomToolStripMenuItem";
            this.viewChatroomToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.viewChatroomToolStripMenuItem.Text = "View Chatroom";
            this.viewChatroomToolStripMenuItem.Click += new System.EventHandler(this.viewChatroomToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // frmAdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::StaffManagementSystem.Properties.Resources._1403808370376;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(684, 461);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(700, 500);
            this.MinimumSize = new System.Drawing.Size(700, 500);
            this.Name = "frmAdminMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminMenu";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allocateLeaveDaysToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewLeaveRequestsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageStaffMembersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewStaffMemberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewChatroomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
    }
}