﻿namespace StaffManagementSystem
{
    partial class frmOutstandingRequests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstRequests = new System.Windows.Forms.ListBox();
            this.lblOutstandingRequests = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.btnCloseByRequests = new System.Windows.Forms.Button();
            this.btnBackFromRequests = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLeaveType = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lstRequests
            // 
            this.lstRequests.FormattingEnabled = true;
            this.lstRequests.Location = new System.Drawing.Point(3, 79);
            this.lstRequests.Name = "lstRequests";
            this.lstRequests.Size = new System.Drawing.Size(224, 316);
            this.lstRequests.TabIndex = 0;
            this.lstRequests.SelectedIndexChanged += new System.EventHandler(this.lstRequests_SelectedIndexChanged);
            // 
            // lblOutstandingRequests
            // 
            this.lblOutstandingRequests.AutoSize = true;
            this.lblOutstandingRequests.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutstandingRequests.Location = new System.Drawing.Point(-2, 49);
            this.lblOutstandingRequests.Name = "lblOutstandingRequests";
            this.lblOutstandingRequests.Size = new System.Drawing.Size(263, 27);
            this.lblOutstandingRequests.TabIndex = 1;
            this.lblOutstandingRequests.Text = "Outstanding Requests";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(242, 278);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 27);
            this.label1.TabIndex = 2;
            this.label1.Text = "End Date:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(242, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 27);
            this.label2.TabIndex = 3;
            this.label2.Text = "Start Date:";
            // 
            // dtpStart
            // 
            this.dtpStart.Enabled = false;
            this.dtpStart.Location = new System.Drawing.Point(242, 200);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(209, 20);
            this.dtpStart.TabIndex = 4;
            // 
            // dtpEnd
            // 
            this.dtpEnd.Enabled = false;
            this.dtpEnd.Location = new System.Drawing.Point(242, 308);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(209, 20);
            this.dtpEnd.TabIndex = 5;
            // 
            // btnCloseByRequests
            // 
            this.btnCloseByRequests.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseByRequests.Location = new System.Drawing.Point(365, 413);
            this.btnCloseByRequests.Name = "btnCloseByRequests";
            this.btnCloseByRequests.Size = new System.Drawing.Size(107, 36);
            this.btnCloseByRequests.TabIndex = 10;
            this.btnCloseByRequests.Text = "Close";
            this.btnCloseByRequests.UseVisualStyleBackColor = true;
            this.btnCloseByRequests.Click += new System.EventHandler(this.btnCloseByRequests_Click);
            // 
            // btnBackFromRequests
            // 
            this.btnBackFromRequests.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackFromRequests.Location = new System.Drawing.Point(12, 413);
            this.btnBackFromRequests.Name = "btnBackFromRequests";
            this.btnBackFromRequests.Size = new System.Drawing.Size(107, 36);
            this.btnBackFromRequests.TabIndex = 9;
            this.btnBackFromRequests.Text = "Back";
            this.btnBackFromRequests.UseVisualStyleBackColor = true;
            this.btnBackFromRequests.Click += new System.EventHandler(this.btnBackFromRequests_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Elephant", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(242, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 27);
            this.label3.TabIndex = 11;
            this.label3.Text = "Leave Type";
            // 
            // txtLeaveType
            // 
            this.txtLeaveType.Enabled = false;
            this.txtLeaveType.Location = new System.Drawing.Point(242, 109);
            this.txtLeaveType.Name = "txtLeaveType";
            this.txtLeaveType.Size = new System.Drawing.Size(209, 20);
            this.txtLeaveType.TabIndex = 12;
            // 
            // frmOutstandingRequests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.txtLeaveType);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnCloseByRequests);
            this.Controls.Add(this.btnBackFromRequests);
            this.Controls.Add(this.dtpEnd);
            this.Controls.Add(this.dtpStart);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblOutstandingRequests);
            this.Controls.Add(this.lstRequests);
            this.MaximumSize = new System.Drawing.Size(500, 500);
            this.MinimumSize = new System.Drawing.Size(500, 500);
            this.Name = "frmOutstandingRequests";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Outstanding Requests";
            this.Load += new System.EventHandler(this.frmOutstandingRequests_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstRequests;
        private System.Windows.Forms.Label lblOutstandingRequests;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.Button btnCloseByRequests;
        private System.Windows.Forms.Button btnBackFromRequests;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLeaveType;
    }
}