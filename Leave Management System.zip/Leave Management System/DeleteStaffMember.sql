use Staff_Management

go
Create Proc sp_DeleteStaff
(
	@id int
)
AS
Begin
Delete FROM tblStaff WHERE staffID = @id
End

go
Create Proc sp_DeleteActiveRequest
(
	@id int
)
AS
Begin
Delete FROM tblActiveRequests Where requestsID = @id
End