﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace StaffManagementServer
{
    class Datahandler
    {
        string conString = @"Data Source=COMPLAB\MUSA;Initial Catalog=Staff_Management;Integrated Security=True";
        SqlConnection connection;
        SqlCommand command;
        string query = null;
        SqlDataAdapter adapter;

        public Datahandler()
        {
            connection = new SqlConnection(conString);
        }

        public List<string> LoadLeave(int id)
        {
            List<string> data = new List<string>();

            Console.WriteLine("Requesting query Select * from tblLeave Where staffIDFK = @id");

            try
            {
                connection.Open();

                using (connection)
                {
                    query = "SELECT * FROM tblLeave WHERE staffIDFK = @id";
                    using (command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                data.Add(reader["leaveID"].ToString() + ";" + reader["staffIDFK"].ToString() + ";" + reader["categorieIDFK"].ToString() + ";" + reader["leaveStatus"].ToString() + ";" + reader["startDate"].ToString() + ";" + reader["endDate"].ToString());
                            }
                        }

                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
                //Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return data;
        }

        public void DeleteActiveRequest(int id)
        {
            Console.WriteLine("Requesting query sp_DeleteActiveRequest");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_DeleteActiveRequest", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                        command.ExecuteNonQuery();
                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }
        }

        public void InsertLeaveData(int staffID, int categorieID, string leaveStatus, DateTime startDate, DateTime endDate)
        {
            Console.WriteLine("Requesting query sp_InsertLeave");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_InsertLeave", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@staffIDFK", SqlDbType.Int).Value = staffID;
                        command.Parameters.Add("@categorieIDFK", SqlDbType.Int).Value = categorieID;
                        command.Parameters.Add("@status", SqlDbType.VarChar).Value = leaveStatus;
                        command.Parameters.Add("@startDate", SqlDbType.Date).Value = startDate;
                        command.Parameters.Add("@endData", SqlDbType.Date).Value = endDate;

                        command.ExecuteNonQuery();
                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }
        }

        public List<string> LoadActiveReports()
        {
            List<string> data = new List<string>();

            Console.WriteLine("Requesting query Select * from tblActiveRequests");

            try
            {
                connection.Open();

                using (connection)
                {
                    query = "SELECT * FROM tblActiveRequests";
                    using (command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                data.Add(reader["requestsID"].ToString() + ";" + reader["staffIDFK"].ToString() + ";" + reader["categorieIDFK"].ToString() + ";" + reader["leaveStatus"].ToString() + ";" + reader["startDate"].ToString() + ";" + reader["endDate"].ToString());
                            }
                        }

                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return data;
        }

        public List<string> LoadActiveReportsForStaffMember(int id)
        {
            List<string> data = new List<string>();

            Console.WriteLine("Requesting query Select * from tblActiveRequests Where staffIDFK = @id");

            try
            {
                connection.Open();

                using(connection)
                {
                    query = "SELECT * FROM tblActiveRequests WHERE staffIDFK = @id";
                    using (command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        using(SqlDataReader reader = command.ExecuteReader())
                        {
                            while(reader.Read())
                            {
                                data.Add(reader["requestsID"].ToString() + ";" + reader["staffIDFK"].ToString() + ";" + reader["categorieIDFK"].ToString() + ";" + reader["leaveStatus"].ToString() + ";" + reader["startDate"].ToString() + ";" + reader["endDate"].ToString());
                            }
                        }

                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }              
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return data;
        }

        public void InsertActiveRequests(int staffID, int categorieID, string leaveStatus, DateTime startDate, DateTime endDate)
        {
            Console.WriteLine("Requesting query sp_InsertActiveRequests");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_InsertActiveRequests", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@staffIDFK", SqlDbType.Int).Value = staffID;
                        command.Parameters.Add("@categorieIDFK", SqlDbType.Int).Value = categorieID;
                        command.Parameters.Add("@status", SqlDbType.VarChar).Value = leaveStatus;
                        command.Parameters.Add("@startDate", SqlDbType.Date).Value = startDate;
                        command.Parameters.Add("@endData", SqlDbType.Date).Value = endDate;

                        command.ExecuteNonQuery();
                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
              //  Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }
        }

        public void UpdateCategories(int length, int id)
        {
            Console.WriteLine("Requesting query sp_UpdateLeaveDays");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_UpdateLeaveDays", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@newLength", SqlDbType.VarChar).Value = length;
                        command.Parameters.Add("@id", SqlDbType.VarChar).Value = id;

                        command.ExecuteNonQuery();
                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }
        }

        public List<string> SelectCategories()
        {
            List<string> selectedData = new List<string>();

            Console.WriteLine("Requesting query Select * From tblCategories");

            try
            {
                connection.Open();

                DataSet ds = new DataSet();
                query = "SELECT * FROM tblCategories";
                adapter = new SqlDataAdapter(query, connection);

                adapter.Fill(ds);

                DataTable dt = ds.Tables[0];

                foreach (DataRow item in dt.Rows)
                {
                    selectedData.Add(item[0].ToString() + ";" + item[1].ToString() + ";" + item[2].ToString());
                }

                Console.WriteLine("Query Successfull");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
             //   Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return selectedData;
        }

        public void DeleteStaff(int id)
        {
            Console.WriteLine("Requesting query sp_DeleteStaff");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_DeleteStaff", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                        command.ExecuteNonQuery();
                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
              //  Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }
        }

        public void UpdateStaff(string title, string name, string surname, string password, int id)
        {
            Console.WriteLine("Requesting query sp_UpdateStaff");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_UpdateStaff", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@title", SqlDbType.VarChar).Value = title;
                        command.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                        command.Parameters.Add("@surname", SqlDbType.VarChar).Value = surname;
                        command.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
                        command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                        command.ExecuteNonQuery();
                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }
        }

        public List<string> SelectAdmin()
        {
            List<string> selectedData = new List<string>();

            Console.WriteLine("Requesting query Select * From tblAdmin");

            try
            {
                connection.Open();

                DataSet ds = new DataSet();
                query = "SELECT * FROM tblAdmin";
                adapter = new SqlDataAdapter(query, connection);

                adapter.Fill(ds);

                DataTable dt = ds.Tables[0];

                foreach (DataRow item in dt.Rows)
                {
                    selectedData.Add(item[0].ToString() + ";" + item[1].ToString() + ";" + item[2].ToString() + ";" + item[3].ToString());
                }

                Console.WriteLine("Query Successfull");
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return selectedData;
        }

        public List<string> SelectStaff()
        {
            List<string> selectedData = new List<string>();

            Console.WriteLine("Requesting query Select * From tblStaff");

            try
            {
                connection.Open();

                DataSet ds = new DataSet();
                query = "SELECT * FROM tblStaff";
                adapter = new SqlDataAdapter(query, connection);

                adapter.Fill(ds);

                DataTable dt = ds.Tables[0];

                foreach (DataRow item in dt.Rows)
                {
                    selectedData.Add(item[0].ToString() + ";" + item[1].ToString() + ";" + item[2].ToString() + ";" + item[3].ToString() + ";" + item[4].ToString());
                }

                Console.WriteLine("Query Successfull");
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
             //   Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return selectedData;
        }

        public void AddStaff(string title, string name, string surname, string password)
        {
            Console.WriteLine("Requesting query sp_InsertStaff");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_InsertStaff", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@title", SqlDbType.VarChar).Value = title;
                        command.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                        command.Parameters.Add("@surname", SqlDbType.VarChar).Value = surname;
                        command.Parameters.Add("@password", SqlDbType.VarChar).Value = password;

                        command.ExecuteNonQuery();
                        Console.WriteLine("Query Successfull");
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
                Console.WriteLine();
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }
        }

        public int ValidateStaffMembers(string name, string password)
        {
            int validateLogin = -1;
            Console.WriteLine("Requesting query sp_LoginStaff");

            try
            {
                connection.Open();

                using(connection)
                {
                    using(command = new SqlCommand("sp_CheckLoginStaff", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                        command.Parameters.Add("@password", SqlDbType.VarChar).Value = password;

                        var retrieve = command.Parameters.Add("@valid", SqlDbType.TinyInt);
                        retrieve.Direction = ParameterDirection.ReturnValue;

                        command.ExecuteNonQuery();

                        validateLogin = (int)retrieve.Value;
                        Console.WriteLine("Query Successfull");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
               // Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return validateLogin;
        }

        public int ValidateAdmin(string name, string password)
        {
            int validateLogin = -1;
            Console.WriteLine("Requesting query sp_CheckLoginAdmin");

            try
            {
                connection.Open();

                using (connection)
                {
                    using (command = new SqlCommand("sp_CheckLoginAdmin", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                        command.Parameters.Add("@password", SqlDbType.VarChar).Value = password;

                        var retrieve = command.Parameters.Add("@valid", SqlDbType.TinyInt);
                        retrieve.Direction = ParameterDirection.ReturnValue;

                        command.ExecuteNonQuery();

                        validateLogin = (int)retrieve.Value;
                        Console.WriteLine("Query Successfull");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Database Error: " + e.Message);
                Console.WriteLine("Query Failed");
              //  Logger l = new Logger(e);
            }
            finally
            {
                connection.Close();
            }

            return validateLogin;
        }
    }
}
