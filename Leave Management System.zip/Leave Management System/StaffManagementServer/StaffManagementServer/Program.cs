﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using HelperLib;

namespace StaffManagementServer
{
    class Program
    {

        public static List<ServerClients> clients = new List<ServerClients>();
        private static byte[] buffer = new byte[1024];
        private static Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        static void Main(string[] args)
        {
            Console.WriteLine(
@"=========================================================================
======================== STAFF MANAGEMENT SERVER ========================
=========================================================================");

            Thread startThread = new Thread(new ThreadStart(ServerStart));
            startThread.Start();

            Console.Read();
        }

        public static void ServerStart()
        {
            Console.WriteLine();
            Console.WriteLine("Server has been started!");
            server.Bind(new IPEndPoint(IPAddress.Any, 3128));
            server.Listen(3128);
            server.BeginAccept(new AsyncCallback(AcceptCallBack), null);
        }

        public static void AcceptCallBack(IAsyncResult ar)
        {
            Socket socket = server.EndAccept(ar);
            clients.Add(new ServerClients(socket));
            string hostName;

            IPEndPoint endPoint = (IPEndPoint)socket.RemoteEndPoint;
            IPAddress ipAddress = endPoint.Address;
            IPHostEntry hostEntry = Dns.GetHostEntry(ipAddress);
            hostName = hostEntry.HostName;

            Console.WriteLine(">>: "+ hostName + " has connected on IP Address => " + socket.LocalEndPoint.ToString());

            Thread beginRecieve = new Thread(new ThreadStart(() =>
            {
                socket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(RecieveCallback), socket);
            }));

            beginRecieve.Start();

            Thread beginAccept = new Thread(new ThreadStart(() =>
            {
                server.BeginAccept(new AsyncCallback(AcceptCallBack), null);
            }));

            beginAccept.Start();
        }

        public static void RecieveCallback(IAsyncResult ar)
        {
            Socket socket = (Socket)ar.AsyncState;
           
            if(socket.Connected)
            {
                int recieved;

                try
                {
                    recieved = socket.EndReceive(ar);
                }
                catch (Exception e)
                {
                    Logger l = new Logger(e);
                    for (int i = 0; i < clients.Count; i++)
                    {
                        if(clients[i].ClientSocket.RemoteEndPoint.ToString().Equals(socket.RemoteEndPoint.ToString()))
                        {
                            clients.RemoveAt(i);
                        }
                    }

                    return;
                }

                if (recieved != 0)
                {
                    byte[] dataBuf = new byte[recieved];
                    Array.Copy(buffer, dataBuf, recieved);
                    string request = (string)dataBuf.Deserialize();
                    string response = string.Empty;
                    int loginReturn = -1;
                    List<string> selectData = new List<string>();
                    HandleRequests handle;

                    for (int i = 0; i < clients.Count; i++)
                    {
                        if (socket.RemoteEndPoint.ToString().Equals(clients[i].ClientSocket.RemoteEndPoint.ToString()))
                        {
                            if (request.Contains("SendMessage"))
                            {
                                handle = new HandleRequests(request, 0);
                                response = handle.message;
                                SendMessageData(socket, response);
                            }
                            else
                            {
                                handle = new HandleRequests(request);
                            }

                            if ((!request.Contains("Insert")) || (!request.Contains("Update")) || (!request.Contains("Delete")))
                            {
                                if (request.Contains("Login"))
                                {
                                    loginReturn = handle.LoginReturn;
                                    response = loginReturn.ToString();
                                    SendLoginData(socket, response);
                                }
                                if (request.Contains("Select"))
                                {
                                    selectData = handle.selectList;
                                    SendSelectList(socket, selectData);
                                }
                            }
                        }
                    }
                }
            }

            socket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(RecieveCallback), socket);
        }

        private static void SendLoginData(Socket socket, string returnValue)
        {
            byte[] data = returnValue.Serialize();
            socket.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(SendCallback), socket);
            server.BeginAccept(new AsyncCallback(AcceptCallBack), null);
        }

        private static void SendSelectList(Socket socket, List<string> returnList)
        {
            byte[] data = returnList.Serialize();
            socket.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(SendCallback), socket);
            server.BeginAccept(new AsyncCallback(AcceptCallBack), null);
        }

        private static void SendMessageData(Socket socket, string messageToSend)
        {
            byte[] data = messageToSend.Serialize();
            socket.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(SendCallback), socket);
            server.BeginAccept(new AsyncCallback(AcceptCallBack), null);
        }

        private static void SendCallback(IAsyncResult AR)
        {
            Socket socket = (Socket)AR.AsyncState;
            socket.EndSend(AR);
        }

    }
}
