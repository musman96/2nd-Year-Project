﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace StaffManagementServer
{
    class Logger
    {
        public Logger(Exception message)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Exception));
            using (TextWriter writer = new StreamWriter("ExceptionLog.xml"))
            {
                serializer.Serialize(writer, message);
            }
        }
    }
}
