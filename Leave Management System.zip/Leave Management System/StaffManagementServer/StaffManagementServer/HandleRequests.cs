﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace StaffManagementServer
{

    class HandleRequests
    {
        private string[] split;
        public int LoginReturn = -1;
        public string message = null;
        public List<string> selectList = new List<string>();
        Datahandler dh;

        public HandleRequests(string messageP, int sommer)
        {
            split = messageP.Split(';');
            message = split[1];

            Console.WriteLine("Message being handled by server");
        }

        public HandleRequests(string requestP)
        {
            dh = new Datahandler();
            Console.WriteLine("Database connection established");

            split = requestP.Split(';');

            string clientRequest = split[0];

            if (clientRequest.Equals("LoginStaff"))
            {
                LoginStaff();
            }

            if (clientRequest.Equals("LoginAdmin"))
            {
                LoginAdmin();
            }

            if (clientRequest.Equals("InsertStaff"))
            {
                AddStaff();
            }

            if(clientRequest.Equals("SelectStaff"))
            {
                SelectStaff();
            }

            if(clientRequest.Equals("UpdateStaff"))
            {
                UpdateStaff();
            }

            if(clientRequest.Equals("DeleteStaff"))
            {
                DeleteStaff();
            }

            if(clientRequest.Equals("SelectCategories"))
            {
                SelectCategories();
            }

            if(clientRequest.Equals("UpdateCategories"))
            {
                UpdateCategories();
            }

            if(clientRequest.Equals("InsertActiveRequest"))
            {
                InsertActiveRequest();
            }

            if (clientRequest.Equals("SelectActiveReportsStaff"))
            {
                LoadActiveReportsForStaffMember();
            }

            if(clientRequest.Equals("SelectActiveReports"))
            {
                LoadActiveReports();
            }

            if (clientRequest.Equals("InsertLeaveData"))
            {
                InsertLeaveData();
            }

            if(clientRequest.Equals("DeleteActiveRequest"))
            {
                DeleteActiveRequest();
            }

            if (clientRequest.Equals("SelectLeave"))
            {
                LoadLeave();
            }

            if(clientRequest.Equals("SelectAdmin"))
            {
                SelectAdmin();
            }
        }
        public void LoadLeave()
        {
            int id = int.Parse(split[1]);
            selectList = dh.LoadLeave(id);
        }

        public void DeleteActiveRequest()
        {
            int id = int.Parse(split[1]);

            dh.DeleteActiveRequest(id);
        }

        public void InsertLeaveData()
        {
            int staffID = int.Parse(split[1]);
            int categorieID = int.Parse(split[2]);
            string status = split[3];
            DateTime startDate = DateTime.Parse(split[4]);
            DateTime endDate = DateTime.Parse(split[5]);

            dh.InsertLeaveData(staffID, categorieID, status, startDate, endDate);
        }

        public void LoadActiveReports()
        {
            selectList = dh.LoadActiveReports();
        }

        private void LoadActiveReportsForStaffMember()
        {
            int id = int.Parse(split[1]);
            selectList = dh.LoadActiveReportsForStaffMember(id);
        }

        private void InsertActiveRequest()
        {
            int staffID = int.Parse(split[1]);
            int categorieID = int.Parse(split[2]);
            string status = split[3];
            DateTime startDate = DateTime.Parse(split[4]);
            DateTime endDate = DateTime.Parse(split[5]);

            dh.InsertActiveRequests(staffID, categorieID, status, startDate, endDate);
        }

        private void UpdateCategories()
        {
            int length = int.Parse(split[1]);
            int id = int.Parse(split[2]);

            dh.UpdateCategories(length, id);
        }

        private void SelectCategories()
        {
            selectList = dh.SelectCategories();
        }

        private void DeleteStaff()
        {
            int id = int.Parse(split[1]);

            dh.DeleteStaff(id);
        }

        private void UpdateStaff()
        {
            string title = split[1];
            string name = split[2];
            string surname = split[3];
            string password = split[4];
            int id = int.Parse(split[5]);

            dh.UpdateStaff(title, name, surname, password, id);
        }

        public void SelectAdmin()
        {
            selectList = dh.SelectAdmin();
        }

        private void SelectStaff()
        {
            selectList = dh.SelectStaff();
        }

        private void AddStaff()
        {
            string title = split[1];
            string name = split[2];
            string surname = split[3];
            string password = split[4];

            dh.AddStaff(title, name, surname, password);
        }

        private void LoginStaff()
        {
            int validNo = -1;
            string name = split[1];
            string password = split[2];

            validNo = dh.ValidateStaffMembers(name, password);
            LoginReturn = validNo;
        }

        private void LoginAdmin()
        {
            int validNo;
            string name = split[1];
            string password = split[2];

            validNo = dh.ValidateAdmin(name, password);
            LoginReturn = validNo;
        }
    }
}
