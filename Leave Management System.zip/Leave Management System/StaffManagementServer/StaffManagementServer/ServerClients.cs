﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace StaffManagementServer
{
    class ServerClients
    {
        public Socket clientSocket;
        public string clientName;

        public ServerClients(Socket socketP)
        {
            this.clientSocket = socketP;
            IPEndPoint endPoint = (IPEndPoint)socketP.RemoteEndPoint;
            IPAddress ipAddress = endPoint.Address;
            IPHostEntry hostEntry = Dns.GetHostEntry(ipAddress);
            this.clientName = hostEntry.HostName;
        }

        public string ClientName
        {
            get { return clientName; }
            set { clientName = value; }
        }
        

        public Socket ClientSocket
        {
            get { return clientSocket; }
            set { clientSocket = value; }
        }
        
    }
}
