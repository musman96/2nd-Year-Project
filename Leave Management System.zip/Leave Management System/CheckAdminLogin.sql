use Staff_Management

go
Create Proc sp_CheckLoginAdmin
(
	@name varchar(30),
	@password varchar(30)
)
AS
Begin

DECLARE @valid tinyint

IF EXISTS (SELECT * FROM tblAdmin WHERE firstName = @name)
BEGIN
	SET @valid = 1;

	IF EXISTS (SELECT * FROM tblAdmin WHERE firstName = @name AND adminPassword = @password)
	BEGIN
		SET @valid = 2;
	END
END
ELSE
BEGIN
	SET @valid = 0;
END

RETURN @valid
End