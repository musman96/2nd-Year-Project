use Staff_Management

go
Create Proc sp_InsertStaff
(
	@title varchar(100),
	@name varchar(30),
	@surname varchar(30),
	@password varchar(30)
)
AS
Begin
Insert Into tblStaff
(staffJobTitle, firstName, lastName, staffPassword)
Values
(@title, @name, @surname, @password)
End
----------------------------------------------------
----------------------------------------------------
go
Create Proc sp_InsertCategories
(
	@name varchar(30),
	@lengthInDays int
)
AS
Begin
Insert Into tblCategories
(categoryName, lengthInDays)
Values
(@name, @lengthInDays)
End
----------------------------------------------------
----------------------------------------------------
go
Create Proc sp_InsertLeave
(
	@staffIDFK int,
	@categorieIDFK int,
	@status varchar(10),
	@startDate date,
	@endData date
)
AS
Begin
Insert Into tblLeave
(staffIDFK, categorieIDFK, leaveStatus, startDate, endDate)
Values
(@staffIDFK, @categorieIDFK, @status, @startDate, @endData)
End
----------------------------------------------------
----------------------------------------------------
go
Create Proc sp_InsertAdmin
(
	@name varchar(30),
	@surname varchar(30),
	@password varchar(30)
)
AS
Begin
Insert Into tblAdmin
(firstName, lastName, adminPassword)
Values
(@name, @surname, @password)
End
----------------------------------------------------
----------------------------------------------------
go
Create Proc sp_InsertLogs
(
	@description varchar(50),
	@date date,
	@time time,
	@location varchar(128)
)
AS
Begin
Insert Into tblExceptionLogs
(exceptionDescription, exceptionDate, exceptionTime, fileLocation)
Values
(@description, @date, @time, @location)
End
----------------------------------------------------
----------------------------------------------------
go
Create Proc sp_InsertActiveRequests
(
	@staffIDFK int,
	@categorieIDFK int,
	@status varchar(10),
	@startDate date,
	@endData date
)
AS
Begin
Insert Into tblActiveRequests
(staffIDFK, categorieIDFK, leaveStatus, startDate, endDate)
Values
(@staffIDFK, @categorieIDFK, @status, @startDate, @endData)
End